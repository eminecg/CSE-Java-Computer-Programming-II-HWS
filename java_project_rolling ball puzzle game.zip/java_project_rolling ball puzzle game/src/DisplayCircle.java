
// Suleyman KELES 150118039
// Emine CIG 150118012

import javafx.animation.PathTransition;
import javafx.geometry.HPos;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polyline;
import javafx.util.Duration;

/*
 * This class performs the movement of the ball 
 * and animation in the game when the user completes the level,
 * It is linked with the Level class.
 */

public class DisplayCircle {
	/*
	 * This method takes the parameters int numberOfLevel, GridPane targetbox. A
	 * circle object from the Circle class is created in the method. Depending on
	 * the number of levels taken from the parameters, level123 (circle: Circle):
	 * void, level45 (circle: Circle): void methods are called to create proper PathTransition animation .
	 */
	public DisplayCircle(int numberOfLevel, GridPane targetbox) {

		// Circle is located proper proper coordinate and indexes and sets its radius and color
		Circle circle = new Circle(65, 65, 15);
		circle.setStroke(Color.ORANGE);
		circle.setFill(Color.ORANGE);

		GridPane.setHalignment(circle, HPos.CENTER);

		targetbox.add(circle, 0, 0);

		// Depending on the level number, proper path transition method is called
		if (numberOfLevel == 0 || numberOfLevel == 1 || numberOfLevel == 2) {
			level123(circle);
		} else if (numberOfLevel == 3 || numberOfLevel == 4) {
			level45(circle);

		}
	}
	// level 1 , level 2 and level 3 is the same complete path sequence.For each level method is used to create PathTransition animation
	public void level123(Circle circle) {

		//PolyLine is used for create a path depending on the points level's complete path line
		Polyline polyline = new Polyline();

		polyline.getPoints().addAll(new Double[] {

				65.0, 65.0, 65.0, 390.0, 82.0, 440.0, 130.0, 456.0, 465.0, 456.0

		});

		PathTransition pathTransition = new PathTransition();
		// Sets the duration for animation
		pathTransition.setDuration(Duration.millis(3000));
		// Circle objects is sets for node of animation
		pathTransition.setNode(circle);
		// PolyLine objects is sets for path of animation
		pathTransition.setPath(polyline);
		//Sets the orientationType od transition  is NONE
		pathTransition.setOrientation(PathTransition.OrientationType.NONE);
		//Sets the CycleCount of transition is 1
		pathTransition.setCycleCount(1);
		// Start the tarnsition
		pathTransition.play();

	}
	// level 4 and level 5 is the same complete path sequence.For each level method is used to create PathTransition animation
	public void level45(Circle circle) {
		//PolyLine is used for create a path depending on the points level's complete path line
		Polyline polyline = new Polyline();

		polyline.getPoints().addAll(new Double[] {

				65.0, 65.0, 65.0, 260.0, 82.0, 310.0, 130.0, 325.0, 390.0, 325.0, 450.0, 300.0, 457.0, 195.0

		});

		PathTransition pathTransition = new PathTransition();
		// Sets the duration for animation
		pathTransition.setDuration(Duration.millis(3000));
		// Circle objects is sets for node of animation
		pathTransition.setNode(circle);
		// PolyLine objects is sets for path of animation
		pathTransition.setPath(polyline);
		//Sets the orientationType od transition  is NONE
		pathTransition.setOrientation(PathTransition.OrientationType.NONE);
		//Sets the CycleCount of transition is 1
		pathTransition.setCycleCount(1);
		// Start the tarnsition
		pathTransition.play();

	}
}


// Suleyman KELES 150118039
// Emine CIG 150118012

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.FileNotFoundException;

/*
 * This class is the main class of the project. 
 * The project works by overriding the "start (Stage primaryStage): void" method
 * from the Applications class.
 * All operations take place in this class.
 */
public class Test extends Application {

	Stage window;
	Scene scenestart, scene1, scene2, scene3, scene4, scene5, sceneFinish;
	ImageView startImage = new ImageView(new Image("startImage.jpeg"));
	ImageView finishImage = new ImageView(new Image("finish.png"));

	/*
	 * In this method, images to be used in the application are created. The window
	 * is set. Scenes are created. The project is linked by creating an object in
	 * the Level class. Scenes are designed using the data obtained from this
	 * object. Appropriate labels, buttons and texts are set for each scene. In this
	 * method, there are a buttons for level passing. The buttons become active when
	 * the user completes the level and provides the transition to the other level.
	 * The number of movements is printed on the screen for each level .
	 */
	@Override
	public void start(Stage primaryStage) throws FileNotFoundException {
		window = primaryStage;
		//Resize ImageViews for  Start and Finish scene
		startImage.setFitHeight(600);
		startImage.setFitWidth(520);

		finishImage.setFitHeight(600);
		finishImage.setFitWidth(520);

		// Creates an object from Level Class to create all level
		Level level = new Level();

		// START SCENE

		BorderPane startPane = new BorderPane();
		HBox hbstartcenter = new HBox(40);
		HBox hbstartbottom = new HBox(40);

		Label starttext = new Label("WELCOME THE GAME");
		starttext.setTextFill(Color.SEASHELL);
		starttext.setFont(Font.font("Courier", FontWeight.EXTRA_BOLD, FontPosture.REGULAR, 40));

		hbstartcenter.setAlignment(Pos.CENTER);
		hbstartcenter.getChildren().addAll(starttext);

		Button startbt = new Button(" START ");
		startbt.setMinHeight(50);
		startbt.setMinWidth(50);
		startbt.setFont(Font.font("Courier", FontWeight.MEDIUM, FontPosture.REGULAR, 15));

		hbstartbottom.getChildren().add(startbt);
		hbstartbottom.setPadding(new Insets(10, 10, 10, 10));
		hbstartbottom.setAlignment(Pos.CENTER);
		startbt.setOnAction(e -> window.setScene(scene1));

		startPane.getChildren().add(startImage);
		startPane.setCenter(hbstartcenter);
		startPane.setBottom(hbstartbottom);

		scenestart = new Scene(startPane, 520, 600);

		// SCENE OF LEVEL 1

		BorderPane mainBoard1 = new BorderPane();
		VBox vbforlabel1 = new VBox(40);
		HBox hbforbt1 = new HBox(40);

		vbforlabel1.setPadding(new Insets(10, 200, 10, 200));
		hbforbt1.setPadding(new Insets(10, 10, 20, 10));

		Text text1 = new Text(" Number Of Movement: ");
		text1.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 10));

		Label currentLevelText1 = new Label(" LEVEL 1 ");
		currentLevelText1.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 25));

		Button passLevel1 = level.getPassLevel1();
		passLevel1.setOnAction(e ->

		window.setScene(scene2));

		vbforlabel1.getChildren().add(currentLevelText1);
		hbforbt1.getChildren().addAll(text1, level.getMovementText1(), passLevel1);

		GridPane level1 = level.getLevelList().get(0);
		mainBoard1.setCenter(level1);
		mainBoard1.setTop(vbforlabel1);
		mainBoard1.setBottom(hbforbt1);

		scene1 = new Scene(mainBoard1, 520, 620);

		// SCENE OF LEVEL 2

		BorderPane mainBoard2 = new BorderPane();
		VBox vbforlabel2 = new VBox(40);
		HBox hbforbt2 = new HBox(40);

		vbforlabel2.setPadding(new Insets(10, 200, 10, 200));
		hbforbt2.setPadding(new Insets(10, 10, 20, 10));

		Label currentLevelText2 = new Label(" LEVEL 2");
		currentLevelText2.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 25));

		Button passLevel2 = level.getPassLevel2();
		passLevel2.setOnAction(e -> window.setScene(scene3));

		Text text2 = new Text(" Number Of Movement: ");
		text2.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 10));

		vbforlabel2.getChildren().add(currentLevelText2);
		hbforbt2.getChildren().addAll(text2, level.getMovementText2(), passLevel2);

		GridPane level2 = level.getLevelList().get(1);
		mainBoard2.setTop(vbforlabel2);
		mainBoard2.setCenter(level2);
		mainBoard2.setBottom(hbforbt2);

		scene2 = new Scene(mainBoard2, 520, 620);

		// SCENE OF LEVEL 3

		BorderPane mainBoard3 = new BorderPane();
		VBox vbforlabel3 = new VBox(40);
		HBox hbforbt3 = new HBox(40);

		vbforlabel3.setPadding(new Insets(10, 200, 10, 200));
		hbforbt3.setPadding(new Insets(10, 10, 20, 10));

		Text text3 = new Text(" Number Of Movement: ");
		text3.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 10));

		Label currentLevelText3 = new Label(" LEVEL 3");
		currentLevelText3.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 25));

		Button passLevel3 = level.getPassLevel3();
		passLevel3.setOnAction(e -> window.setScene(scene4));

		vbforlabel3.getChildren().add(currentLevelText3);
		hbforbt3.getChildren().addAll(text3, level.getMovementText3(), passLevel3);

		GridPane level3 = level.getLevelList().get(2);
		mainBoard3.setCenter(level3);
		mainBoard3.setTop(vbforlabel3);
		mainBoard3.setBottom(hbforbt3);

		scene3 = new Scene(mainBoard3, 520, 620);

		// SCENE OF LEVEL 4

		BorderPane mainBoard4 = new BorderPane();
		VBox vbforlabel4 = new VBox(40);
		HBox hbforbt4 = new HBox(40);

		vbforlabel4.setPadding(new Insets(10, 200, 10, 200));
		hbforbt4.setPadding(new Insets(10, 10, 20, 10));

		Text text4 = new Text(" Number Of Movement: ");
		text4.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 10));

		Label currentLevelText4 = new Label(" LEVEL 4");
		currentLevelText4.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 25));

		Button passLevel4 = level.getPassLevel4();
		passLevel4.setOnAction(e -> window.setScene(scene5));

		vbforlabel4.getChildren().add(currentLevelText4);
		hbforbt4.getChildren().addAll(text4, level.getMovementText4(), passLevel4);

		GridPane level4 = level.getLevelList().get(3);
		mainBoard4.setCenter(level4);
		mainBoard4.setTop(vbforlabel4);
		mainBoard4.setBottom(hbforbt4);

		scene4 = new Scene(mainBoard4, 520, 620);

		// SCENE OF LEVEL 5

		BorderPane mainBoard5 = new BorderPane();
		VBox vbforlabel5 = new VBox(40);
		HBox hbforbt5 = new HBox(40);

		vbforlabel5.setPadding(new Insets(10, 200, 10, 200));
		hbforbt5.setPadding(new Insets(10, 10, 20, 10));

		Text text5 = new Text(" Number Of Movement: ");
		text5.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 10));

		Label currentLevelText5 = new Label(" LEVEL 5");
		currentLevelText5.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 25));

		Button passLevel5 = level.getPassLevel5();
		passLevel5.setOnAction(e -> window.setScene(sceneFinish));

		vbforlabel5.getChildren().add(currentLevelText5);

		GridPane level5 = level.getLevelList().get(4);
		hbforbt5.getChildren().addAll(text5, level.getMovementText5(), passLevel5);

		mainBoard5.setCenter(level5);
		mainBoard5.setTop(vbforlabel5);
		mainBoard5.setBottom(hbforbt5);

		scene5 = new Scene(mainBoard5, 520, 620);

		// FINISH SCENE

		StackPane finishPane = new StackPane();
		VBox vbfinishcenter = new VBox(40);

		Label finishText1 = new Label(" CONGRATULATIONS ");
		Label finishText2 = new Label("  COMPLETED GAME  ");

		finishText1.setTextFill(Color.ROSYBROWN);
		finishText1.setFont(Font.font("Courier", FontWeight.EXTRA_BOLD, FontPosture.REGULAR, 40));
		finishText2.setTextFill(Color.ROSYBROWN);
		finishText2.setFont(Font.font("Courier", FontWeight.EXTRA_BOLD, FontPosture.REGULAR, 30));

		vbfinishcenter.getChildren().addAll(finishText1, finishText2);
		vbfinishcenter.setAlignment(Pos.CENTER);

		finishPane.getChildren().addAll(finishImage);
		finishPane.getChildren().addAll(vbfinishcenter);

		sceneFinish = new Scene(finishPane, 520, 600);

		window.setTitle("GAME");
		window.setScene(scenestart);
		window.show();
	}

	public static void main(String[] args) throws FileNotFoundException {

		launch(args);

	}
}
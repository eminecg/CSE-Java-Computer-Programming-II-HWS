
// Suleyman KELES 150118039
// Emine CIG 150118012

import javafx.event.EventHandler;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/* 
 * This class collects and processes data from all classes in the project and sends it to the Test class.
 *  (This information is used by creating an object of this class in the Test Class)
 */
public class Level {

	// Holds each gridPane is created in levelCreation class in a sequence
	private static ArrayList<GridPane> levelList = new ArrayList<GridPane>();
	// Holds each LevelCreation Class object is created in this class in a sequence
	private static ArrayList<LevelCreation> levelCreations = new ArrayList<LevelCreation>();
	// Holds each CompletedLevels Class object is created in this class in a sequence
	private static ArrayList<CompletedLevels> levels = new ArrayList<CompletedLevels>();

	// Holds address of the current level txt file
	private String tempLevel;
	//Number of level
	private int numberOfLevel = 5;

	//Boolean variables is used to hold each level pass state and to  set Button active and passive situation
	private static boolean levelPassed1 = false;
	private static boolean levelPassed2 = false;
	private static boolean levelPassed3 = false;
	private static boolean levelPassed4 = false;
	private static boolean levelPassed5 = false;
	//Button variable is used to set current active or passive status of level passing
	Button passLevel1 = new Button("NEXT LEVEL");
	Button passLevel2 = new Button("NEXT LEVEL");
	Button passLevel3 = new Button("NEXT LEVEL");
	Button passLevel4 = new Button("NEXT LEVEL");
	Button passLevel5 = new Button("FINISH");

	//Holds source ImageView (Mouse drag detected )index values
	private int sourceRowIndex, sourceColumnIndex;

	// Source ImageView and Target ImageView
	private ImageView sourceiv;
	private ImageView targetiv;

	// Curseur value
	private int curseur = 0;

	//Number of movement value is used for each level after updates each times zero value
	private static int numberOfMovement = 0;

	//Text Variable for each level  is declared separated to get current value in screen
	private static Text movementText1 = new Text("0");
	private static Text movementText2 = new Text("0");
	private static Text movementText3 = new Text("0");
	private static Text movementText4 = new Text("0");
	private static Text movementText5 = new Text("0");

	/*
	 * This method, Searches for input files in project files. (Accesses the
	 * addresses of the input txt files one by one) Creates an object in the LevelCreation class using the address of each level
	 */

	public Level() throws FileNotFoundException {

		// Sets texts font property
		getMovementText1().setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 15));
		getMovementText2().setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 15));
		getMovementText3().setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 15));
		getMovementText4().setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 15));
		getMovementText5().setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.REGULAR, 15));

		//Sets the states of the toggle buttons between screens
		this.passLevel1.setDisable(!levelPassed1);
		this.passLevel2.setDisable(!levelPassed2);
		this.passLevel3.setDisable(!levelPassed3);
		this.passLevel4.setDisable(!levelPassed4);
		this.passLevel5.setDisable(!levelPassed5);

		//Depend on the level number obtains base path of each level txt file and creates with these address an LevelCreation Object
		for (int j = 1; j < numberOfLevel + 1; j++) {

			URL url = getClass().getResource(("level").concat(Integer.toString(j)).concat(".txt"));
			this.tempLevel = url.getPath();

			LevelCreation l = new LevelCreation(getTempLevel());
			// Adds this object to the Level Creation list to use for mouse movement operation
			this.levelCreations.add(l);

			// Adds this gridPane is created at LevelCreation class to levelList list for use to mouse movement operation
			this.levelList.add(l.getGameBoard());

			//Creates an CompletedLevel Class Object for current level number and add it to the Levels list for use to check level completed operation
			CompletedLevels createLevelList = new CompletedLevels(j);
			getLevels().add(createLevelList);

		}

		// This loop is used for each ImageView for each level gridPane to perform proper mouse movement operation
		for (int i = 0; i < numberOfLevel; i++) {

			for (Images iv : getLevelCreations().get(i).getImages()) {

				//After controlling ImageView Tile can move, calls setUpGestureSource method for this ImageView
				if (iv.isCheckMoveProperty()) {

					setupGestureSource(iv.getTileImage(),getLevelList().get(i));

				}
				//After controlling ImageView Tile can move or isCheckEmpty(controls it's id is "EmptyFree" ),
				// calls setUpGestureTarget method for this gridPane  with current Level number and ımages list
				if (iv.isCheckMoveProperty() || iv.isCheckEmpty()) {

					setupGestureTarget(getLevelList().get(i), getLevelCreations().get(i).getImages(), i);

				}
			}
		}
	}

	/*
	 * The checkLevelCompleted method checks whether the user complete the level.
	 * Its parameters are a list with the objects of the Images Class, level number and GridPane.
	 */

	public void checkLevelCompleted(List<Images> images, int numberOfLevel, GridPane targetbox) {

		boolean check = false;

		for (int i = 0; i < images.size(); i++) {
			/*
			 * With the current level's completed level in the "levels: ArrayList <CompletedLevels>"
			 * list, After controlling ImageView is not null ,it checks the level the user has made at that moment.Each tile uses the
			 * id of the imageView in the control process.
			 */

			if (getLevels().get(numberOfLevel).getLevel().get(i) != null) {

				// Assign id to String variablle of these tile ImageViews to check equality
				String levelid = getLevels().get(numberOfLevel).getLevel().get(i).getId();
				String imagesid = images.get(i).getId();

				if (levelid.equals(imagesid)) {
					check = true;

				}
				// Returns "check: Boolean" as "false" if the lists it compares are not equal then breaks the loop
				else if (!levelid.equals(imagesid)) {

					check = false;
					break;
				}
			} else if (getLevels().get(numberOfLevel).getLevel().get(i) == null) {
				check = true;
			}
		}
		/*For each level number;
		 * Updates the numberOfMovement value with each comparison process. And updates
		 * movement text variable for each level with its updated movement value after
		 * converted to String type. Returns "levelPassed: Boolean" as "true" if the
		 * lists it compares are equal.It controls the active and passive states of the
		 * buttons we use in the test class with the disable method.It then creates an object from the DisplayPane
		 * class for the circle to move.
		 * If level is completed, reset the numberOfMovement value to the next level.
		 */
		if (numberOfLevel == 0) {

			setNumberOfMovement(getNumberOfMovement() + 1);
			getMovementText1().setText(Integer.toString(getNumberOfMovement()));

			if (check) {
				if (!isLevelPassed1()) {

					setLevelPassed1(true);
					DisplayCircle displayCircle = new DisplayCircle(numberOfLevel, targetbox);
					setNumberOfMovement(0);
					getPassLevel1().setDisable(!isLevelPassed1());
				}

			}

		}

		if (numberOfLevel == 1) {

			setNumberOfMovement(getNumberOfMovement() + 1);
			getMovementText2().setText(Integer.toString(getNumberOfMovement()));

			if (check) {
				if (!isLevelPassed2()) {

					setLevelPassed2(true);
					DisplayCircle displayCircle = new DisplayCircle(numberOfLevel, targetbox);
					setNumberOfMovement(0);
					getPassLevel2().setDisable(!isLevelPassed2());
				}
			}
		}

		if (numberOfLevel == 2) {

			setNumberOfMovement(getNumberOfMovement() + 1);
			getMovementText3().setText(Integer.toString(getNumberOfMovement()));

			if (check) {
				if (!isLevelPassed3()) {

					setLevelPassed3(true);
					DisplayCircle displayCircle = new DisplayCircle(numberOfLevel, targetbox);
					setNumberOfMovement(0);
					getPassLevel3().setDisable(!isLevelPassed3());

				}
			}
		}
		if (numberOfLevel == 3) {

			setNumberOfMovement(getNumberOfMovement() + 1);
			getMovementText4().setText(Integer.toString(getNumberOfMovement()));

			if (check) {
				if (!isLevelPassed4()) {

					setLevelPassed4(true);
					DisplayCircle displayCircle = new DisplayCircle(numberOfLevel, targetbox);
					setNumberOfMovement(0);
					getPassLevel4().setDisable(!isLevelPassed4());

				}
			}
		}
		if (numberOfLevel == 4) {

			setNumberOfMovement(getNumberOfMovement() + 1);
			getMovementText5().setText(Integer.toString(getNumberOfMovement()));

			if (check) {
				if (!isLevelPassed5()) {

					setLevelPassed5(true);
					DisplayCircle displayCircle = new DisplayCircle(numberOfLevel, targetbox);
					setNumberOfMovement(0);
					getPassLevel5().setDisable(!isLevelPassed5());
				}
			}
		}
	}

	/*
	 * The setupGestureSource method allows objects in the game to be moved using
	 * the mouse drag .Gets the object of type ImageView as a parameter.
	 */

	public void setupGestureSource(ImageView source,GridPane gridPane) {
		/*
		 * The index values of the object held by the mouse are assigned to the
		 * imageView object used as a parameter in the method.Updates the SourceRowIndex
		 * and SourceColumnIndex values.
		 */
		source.setOnDragDetected(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {

				// Sets SourceRowIndex Value and SourceColumnIndex Value
				Object o = event.getTarget();

				// Sets index value of source object
				setSourceRowIndex( gridPane.getRowIndex((ImageView) o));
				setSourceColumnIndex(gridPane.getColumnIndex((ImageView) o));


				// Creates an DragBoard class object to allow any transfer mode
				Dragboard dragboard = source.startDragAndDrop(TransferMode.MOVE);

				//Creates an ClipBoardContent Class object to put a image on dragboard
				ClipboardContent content = new ClipboardContent();

				Image sourceImage = source.getImage();

				content.putImage(sourceImage);
				dragboard.setContent(content);

				sourceiv = source;

				event.consume();
			}
		});

		// The SetOnMouseEntered method also allows editing of the "cursor" type HAND .
		source.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				source.setCursor(Cursor.HAND);
				setCurseur((int) e.getSceneX());
			}
		});

	}

	/*
	 * The "setupGestureTarget" method has three parameters. These; a GridPane type
	 * object, a variable that specifies the number of current level  and list holding
	 * objects of type Images Class.
	 */

	public void setupGestureTarget(final GridPane targetBox, List<Images> images, int numberOfLevel) {
		/*
		 * The SetOnDragOver method checks whether the object of the Dragboard class has
		 * an "image" value. Then it sets the transfer mode to "move".
		 */
		targetBox.setOnDragOver(new EventHandler<DragEvent>() {
			@Override
			public void handle(DragEvent event) {

				Dragboard dragboard = event.getDragboard();

				if (dragboard.hasImage()) {

					event.acceptTransferModes(TransferMode.MOVE);
				}
				event.consume();
			}
		});
		/*
		 * The SetOnDragDropped method synchronizes the dragboard object in the "event"
		 * to the Dragboard object. Checks whether the dragboard object has an
		 * "image".If it does, it updates the "image" in the data of
		 * "Sourceiv Imageview" using the "image" on the dragboard.
		 *
		 * Using the "Event" object, the object held by the getTarget method is
		 * obtained. The index values on the gridpane of this object are reached to use
		 * gridpane objects getRowIndex() and getColumnIndex() methods. It checks whether
		 * these values are the same as the values of the first mouse drag event object.
		 *
		 */
		targetBox.setOnDragDropped(new EventHandler<DragEvent>() {
			@Override
			public void handle(DragEvent event) {

				Dragboard dragboard = event.getDragboard();

				if (dragboard.hasImage()) {

					sourceiv.setImage(dragboard.getImage());

					// Gets target ImageView Object
					Object o = event.getTarget();

					// Sets index value of tarhet object
					int row = targetBox.getRowIndex((ImageView) o);
					int column = targetBox.getColumnIndex((ImageView) o);

					if (!o.equals(sourceiv)) {
						/*
						 * The ID of the object is controlled because it can only move to the areas with the objects with the "emptyFree" of ID.
						 * Object is provided to move only one unit horizontally or vertically.
						 */
						if (images.get(row * 4 + column).getId() == ("emptyFree")) {
							if ((column == getSourceColumnIndex()
									&& ((row == getSourceRowIndex() + 1) || (row == getSourceRowIndex() - 1)))
									|| (row == getSourceRowIndex() && ((column == getSourceColumnIndex() + 1)
									|| (column == getSourceColumnIndex() - 1)))) {
								/*
								 * Displacement is done on the gridpane given as a parameter (swap operation)
								 * There is an arrayList containing "images" objects that are given as
								 * parameters. Using the coordinates of the displaced objects, their indexes on
								 * the list is updated.
								 */
								targetBox.getChildren().remove(o);
								targetBox.getChildren().remove(sourceiv);
								targetBox.add(sourceiv, column, row);
								targetBox.add((ImageView) o, getSourceColumnIndex(), getSourceRowIndex());

								Images isource = images.get(getSourceRowIndex() * 4 + getSourceColumnIndex());
								Images itarget = images.get(row * 4 + column);

								images.set(4 * row + column, null);
								images.set(4 * row + column, isource);
								images.set(4 * getSourceRowIndex() + getSourceColumnIndex(), null);
								images.set(4 * getSourceRowIndex() + getSourceColumnIndex(), itarget);
								/*
								 * The CheckLevelCompleted method is called using the level number, the gridpane
								 * structure of that level and the list containing "images" objects. In this
								 * way, it is checked whether the level is completed or not at every displacement operation.
								 */
								checkLevelCompleted(images, numberOfLevel, targetBox);

							}
						}
					}
					event.setDropCompleted(true);
				} else {
					event.setDropCompleted(false);
				}
				event.consume();
			}
		});

	}

	// Getter and Setter Methods

	public ArrayList<GridPane> getLevelList() {
		return levelList;
	}

	public void setLevelList(ArrayList<GridPane> levelList) {
		this.levelList = levelList;
	}

	public String getTempLevel() {
		return tempLevel;
	}

	public void setTempLevel(String tempLevel) {
		this.tempLevel = tempLevel;
	}

	public ImageView getSourceiv() {
		return sourceiv;
	}

	public void setSourceiv(ImageView sourceiv) {
		this.sourceiv = sourceiv;
	}

	public ImageView getTargetiv() {
		return targetiv;
	}

	public void setTargetiv(ImageView targetiv) {
		this.targetiv = targetiv;
	}

	public int getSourceRowIndex() {
		return sourceRowIndex;
	}

	public void setSourceRowIndex(int sourceRowIndex) {
		this.sourceRowIndex = sourceRowIndex;
	}

	public int getSourceColumnIndex() {
		return sourceColumnIndex;
	}

	public void setSourceColumnIndex(int sourceColumnIndex) {
		this.sourceColumnIndex = sourceColumnIndex;
	}

	public int getCurseur() {
		return curseur;
	}

	public void setCurseur(int curseur) {
		this.curseur = curseur;
	}

	public static ArrayList<CompletedLevels> getLevels() {
		return levels;
	}

	public static void setLevels(ArrayList<CompletedLevels> levels) {
		Level.levels = levels;
	}

	public ArrayList<LevelCreation> getLevelCreations() {
		return levelCreations;
	}

	public void setLevelCreations(ArrayList<LevelCreation> levelCreations) {
		this.levelCreations = levelCreations;
	}

	public static int getNumberOfMovement() {
		return numberOfMovement;
	}

	public static void setNumberOfMovement(int numberOfMovement) {
		Level.numberOfMovement = numberOfMovement;
	}

	public static boolean isLevelPassed1() {
		return levelPassed1;
	}

	public static void setLevelPassed1(boolean levelPassed1) {
		Level.levelPassed1 = levelPassed1;
	}

	public static boolean isLevelPassed2() {
		return levelPassed2;
	}

	public static void setLevelPassed2(boolean levelPassed2) {
		Level.levelPassed2 = levelPassed2;
	}

	public static boolean isLevelPassed3() {
		return levelPassed3;
	}

	public static void setLevelPassed3(boolean levelPassed3) {
		Level.levelPassed3 = levelPassed3;
	}

	public static boolean isLevelPassed4() {
		return levelPassed4;
	}

	public static void setLevelPassed4(boolean levelPassed4) {
		Level.levelPassed4 = levelPassed4;
	}

	public static boolean isLevelPassed5() {
		return levelPassed5;
	}

	public static void setLevelPassed5(boolean levelPassed5) {
		Level.levelPassed5 = levelPassed5;
	}

	public static Text getMovementText1() {
		return movementText1;
	}

	public static void setMovementText1(Text movementText1) {
		Level.movementText1 = movementText1;
	}

	public static Text getMovementText2() {
		return movementText2;
	}

	public static void setMovementText2(Text movementText2) {
		Level.movementText2 = movementText2;
	}

	public static Text getMovementText3() {
		return movementText3;
	}

	public static void setMovementText3(Text movementText3) {
		Level.movementText3 = movementText3;
	}

	public static Text getMovementText4() {
		return movementText4;
	}

	public static void setMovementText4(Text movementText4) {
		Level.movementText4 = movementText4;
	}

	public static Text getMovementText5() {
		return movementText5;
	}

	public static void setMovementText5(Text movementText5) {
		Level.movementText5 = movementText5;
	}

	public Button getPassLevel1() {
		return passLevel1;
	}

	public void setPassLevel1(Button passLevel1) {
		this.passLevel1 = passLevel1;
	}

	public Button getPassLevel2() {
		return passLevel2;
	}

	public void setPassLevel2(Button passLevel2) {
		this.passLevel2 = passLevel2;
	}

	public Button getPassLevel3() {
		return passLevel3;
	}

	public void setPassLevel3(Button passLevel3) {
		this.passLevel3 = passLevel3;
	}

	public Button getPassLevel4() {
		return passLevel4;
	}

	public void setPassLevel4(Button passLevel4) {
		this.passLevel4 = passLevel4;
	}

	public Button getPassLevel5() {
		return passLevel5;
	}

	public void setPassLevel5(Button passLevel5) {
		this.passLevel5 = passLevel5;
	}
}

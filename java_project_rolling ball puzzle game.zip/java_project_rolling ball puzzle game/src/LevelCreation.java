
// Suleyman KELES 150118039
// Emine CIG 150118012

import javafx.scene.layout.GridPane;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*
 * This class creates the levels in the game by processing the given input files address in the Concructor
 */
public class LevelCreation {
	//Holds each tile Imaegview  proper indexes of current level
	private GridPane gameBoard = new GridPane();
	//Holds each tile ImageView proper index of current level
	private List<Images> images = new ArrayList<Images>(15);

	// Holds data that obtained line bu line
	private String id;
	private String type;
	private String property;

	//Holds ındex value of current ImageView that is added gridPane
	private int rowIndex, coloumnIndex;

	/*
	 * It takes the base path of the level files given as parameters. The files are
	 * in ".txt" format. . Reads the lines in the files in order. With this information, it creates objects from the Images
	 * class using id and type property for each line. Adds "images: List <Images>" to these objects.
	 * Objects in the "images: List <Images>" List are added with this GridPane proper coordinates (rowIndex: int, coloumnIndex: int).
	 */
	public LevelCreation(String tempLevel) throws FileNotFoundException {
		// Creates a file object with given address
		File file = new File(tempLevel);
		// Creates scanner objects to read this file
		Scanner scanner = new Scanner(file);

		//After checking that the line is there and it is not empty starts scanning this line in a sequence
		while (scanner.hasNextLine()) {

			//Assign data of each line to variable
			String line = (scanner.nextLine());

			if (!line.isEmpty()) {

				//Seperates with commo this string type variable ,and assign each part an String array
				String[] seperatedLine = line.split(",");

				// Arrays items datas are assign id ,type and property variables
				setId(seperatedLine[0]);
				setType(seperatedLine[1]);
				setProperty(seperatedLine[2]);

				// Creates a Images Class object with type and property data
				Images i = new Images(getType(), getProperty());
				// Added to the Images list created this object
				this.images.add(i);

				// Depending on the ıd , sets the index value
				this.rowIndex = (int) (((Integer.parseInt(getId())) - 1) / 4);
				this.coloumnIndex = (int) (((Integer.parseInt(getId())) - 1) % 4);
				// ImageView which is obtained from ımages object ,is added to gridPane at the proper index value
				getGameBoard().add(i.getTileImage(), coloumnIndex, rowIndex);

			}
		}
	}

	// Getter And Setter Methods

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public GridPane getGameBoard() {
		return gameBoard;
	}

	public void setGameBoard(GridPane gameBoard) {
		this.gameBoard = gameBoard;
	}

	public List<Images> getImages() {
		return images;
	}

	public void setImages(List<Images> images) {
		this.images = images;
	}

	public int getColoumnIndex() {
		return coloumnIndex;
	}

	public void setColoumnIndex(int coloumnIndex) {
		this.coloumnIndex = coloumnIndex;
	}

	public int getRowIndex() {
		return rowIndex;
	}

	public void setRowIndex(int rowIndex) {
		this.rowIndex = rowIndex;
	}
}
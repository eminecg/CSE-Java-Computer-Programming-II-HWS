
// Suleyman KELES 150118039
// Emine CIG 150118012

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


// Images class have all tile Image in the game . This ımages is converted ImageView . And these are public declared because of used subclass
public class Images {

	public ImageView curvediPipe00 = (new ImageView(new Image("curvedPipe00.png")));
	public ImageView curvediPipe01 = new ImageView(new Image("curvedPipe01.png"));
	public ImageView curvediPipe10 = new ImageView(new Image("curvedPipe10.png"));
	public ImageView curvediPipe11 = new ImageView(new Image("curvedPipe11.png"));
	public ImageView finishHorizontalLeft = new ImageView(new Image("finishHorizontalLeft.png"));
	public ImageView finishVerticalDown = new ImageView(new Image("finishVerticalDown.png"));
	public ImageView pipeHorizontal = new ImageView(new Image("pipeHorizontal.png"));
	public ImageView pipeVertical = new ImageView(new Image("pipeVertical.png"));
	public ImageView startHorizontal = new ImageView(new Image("startHorizontal.png"));
	public ImageView startVertical = new ImageView(new Image("startVertical.png"));
	public ImageView empty = new ImageView(new Image("empty.png"));
	public ImageView emptyFree = new ImageView(new Image("emptyFree.png"));
	public ImageView PipeStaticHorizontal = new ImageView(new Image("PipeStaticHorizontal.png"));
	public ImageView PipeStaticVertical = new ImageView(new Image("PipeStaticVertical.png"));
	public ImageView pipeStatic00 = new ImageView(new Image("pipeStatic00.png"));
	public ImageView pipeStatic01 = new ImageView(new Image("pipeStatic01 .png"));
	public ImageView pipeStatic10 = new ImageView(new Image("pipeStatic10.png"));
	public ImageView pipeStatic11 = new ImageView(new Image("pipeStatic11.png"));

	private String id;
	private boolean checkEmpty = false;
	private boolean checkMoveProperty = false;
	private ImageView tileImage = null;

	/*
	 * There are two Constructer Methods in this class. The "Images ()" method is
	 * used in the CompletedLevels class, the
	 * "Images (String type, String property)" method is used in the LevelCreation
	 * class.
	 */

	public Images() {

	}

	public Images(String type, String property) {

		//After proper id and type of ImageView is selected ,this Imageview is resized and sets its id
		switch (type) {

		case "Starter":
			if (property.equals("Vertical")) {

				setTileImage(sizeImage(startVertical));
				setId("startVertical");

			} else if (property.equals("Horizontal")) {

				setTileImage(sizeImage(startHorizontal));
				setId("startHorizontal");
			}
			break;

		case "Empty":
			if (property.equals("none")) {

				setTileImage(sizeImage(empty));
				setId("empty");

			} else if (property.equals("Free")) {

				setTileImage((sizeImage(emptyFree)));
				setId("emptyFree");

			}
			break;

		case "Pipe":
			if (property.equals("00")) {

				setTileImage(sizeImage(curvediPipe00));
				setId("curvediPipe00");

			} else if (property.equals("01")) {

				setTileImage(sizeImage(curvediPipe01));
				setId("curvediPipe01");

			} else if (property.equals("10")) {

				setTileImage(sizeImage(curvediPipe10));
				setId("curvediPipe10");

			} else if (property.equals("11")) {

				setTileImage(sizeImage(curvediPipe11));
				setId("curvediPipe11");

			} else if (property.equals("Horizontal")) {

				setTileImage(sizeImage(pipeHorizontal));
				setId("pipeHorizontal");

			} else if (property.equals("Vertical")) {

				setTileImage(sizeImage(pipeVertical));
				setId("pipeVertical");

			}
			break;

		case "PipeStatic":
			if (property.equals("Vertical")) {

				setTileImage(sizeImage(PipeStaticVertical));
				setId("PipeStaticVertical");

			} else if (property.equals("Horizontal")) {

				setTileImage(sizeImage(PipeStaticHorizontal));
				setId("PipeStaticHorizontal");
			}

			else if (property.equals("00")) {

				setTileImage(sizeImage(pipeStatic00));
				setId("pipeStatic00");
			} else if (property.equals("01")) {

				setTileImage(sizeImage(pipeStatic01));
				setId("pipeStatic01");
			} else if (property.equals("10")) {

				setTileImage(sizeImage(pipeStatic10));
				setId("pipeStatic10");
			} else if (property.equals("11")) {

				setTileImage(sizeImage(pipeStatic11));
				setId("pipeStatic11");
			}

			break;

		case "End":
			if (property.equals("Vertical")) {

				setTileImage(sizeImage(finishVerticalDown));
				setId("finishVerticalDown");

			} else if (property.equals("Horizontal")) {

				setTileImage(sizeImage((finishHorizontalLeft)));
				setId("finishHorizontalLeft");
			}
			break;
		}

		checkMove(getTileImage());

	}

	/*
	 * The method that controls which tile is can move "
	 * This method takes one ImageView type object as a parameter. It checks
	 * the IDs of the objects after controling ImageView is not null. If the given imageview is one of the tiles imageview
	 * ids that can move (curvedPipes, pipeHorizontal, pipeVertical,Empty,), the
	 * checkMoveProperty Boolean value is updated to true. Also, if Imageview with
	 * the given ImageView emptyfree id is given, the checkempty Boolean value is
	 * updated to true.
	 */
	public void checkMove(ImageView iv) {
		//

		if (!(iv.equals(null))) {

			if ((iv == curvediPipe00) || (iv == curvediPipe01) || (iv == curvediPipe10) || (iv == curvediPipe11)) {
				setCheckMoveProperty(true);

			} else if (iv == pipeHorizontal || iv == (pipeVertical)) {
				setCheckMoveProperty(true);

			} else if (iv == (empty)) {
				setCheckMoveProperty(true);

			}

			else if (iv == emptyFree) {

				setCheckMoveProperty(false);
				setCheckEmpty(true);
			}
		}

	}

	/*
	 * The sizeImage method takes an ImageView.
	 * Assigns  new width and height values to the objects here to appear proportionally
	 * on the screen.
	 */

	public ImageView sizeImage(ImageView imageView) {
		if (imageView != null) {
			imageView.setFitWidth(130);
			imageView.setFitHeight(130);
			return imageView;
		}
		return null;
	}

	/* Getter/Setter Methods */

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isCheckEmpty() {
		return checkEmpty;
	}

	public void setCheckEmpty(boolean checkEmpty) {
		this.checkEmpty = checkEmpty;
	}

	public ImageView getTileImage() {
		return tileImage;
	}

	public void setTileImage(ImageView tileImage) {
		this.tileImage = tileImage;
	}

	public boolean isCheckMoveProperty() {
		return checkMoveProperty;
	}

	public void setCheckMoveProperty(boolean checkMoveProperty) {
		this.checkMoveProperty = checkMoveProperty;
	}
}
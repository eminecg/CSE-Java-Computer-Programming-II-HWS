
// Suleyman KELES 150118039
// Emine CIG 150118012

import javafx.scene.image.ImageView;
import java.util.ArrayList;

/*
	CompletedLevel Class is subclass of the Images Class.This is used for create each level complete path sequence list .
 */
public class CompletedLevels extends Images {

	private ArrayList<ImageView> level = new ArrayList<ImageView>(15);

	/*
	 * This class contains one constructor method. This method is used in the Level
	 * class to check current level whether is complete. Takes LevelNumber as a parameter. It processes this number with
	 * if-else blocks. It creates correct puzzle sequence according to the level
	 * number after setting id's of Imageviews. Adds them to the level: ArrayList <ImageView> ArrayList.
	 */
	public CompletedLevels(int LevelNumber) {

		startHorizontal.setId("startHorizontal");
		startVertical.setId("startVertical");

		empty.setId("empty");
		emptyFree.setId("emptyFree");

		pipeVertical.setId("pipeVertical");
		pipeHorizontal.setId("pipeHorizontal");

		curvediPipe00.setId("curvediPipe00");
		curvediPipe01.setId("curvediPipe01");
		curvediPipe10.setId("curvediPipe10");
		curvediPipe11.setId("curvediPipe11");

		PipeStaticHorizontal.setId("PipeStaticHorizontal");
		PipeStaticVertical.setId("PipeStaticVertical");

		finishHorizontalLeft.setId("finishHorizontalLeft");
		finishVerticalDown.setId("finishVerticalDown");

		pipeStatic00.setId("pipeStatic00");
		pipeStatic01.setId("pipeStatic01");
		pipeStatic10.setId("pipeStatic10");
		pipeStatic11.setId("pipeStatic11");

		if (LevelNumber == 1) {
			level.clear();

			createLevel1((ArrayList<ImageView>) level);

		} else if (LevelNumber == 2) {
			level.clear();

			createLevel2((ArrayList<ImageView>) level);

		} else if (LevelNumber == 3) {
			level.clear();

			createLevel3((ArrayList<ImageView>) level);

		} else if (LevelNumber == 4) {
			level.clear();

			createLevel4((ArrayList<ImageView>) level);

		} else if (LevelNumber == 5) {
			level.clear();

			createLevel5((ArrayList<ImageView>) level);

		}

	}
	/* Methods for each level is used to create right sequence of path,
	assigns null to tiles other than those used for the path .*/


	// LEVEL 1
	public void createLevel1(ArrayList<ImageView> level) {

		startVertical.setId("startVertical");
		getLevel().add(0, sizeImage(startVertical));

		empty.setId("empty");
		getLevel().add(1, sizeImage(empty));

		empty.setId("empty");
		getLevel().add(2, sizeImage(empty));

		empty.setId("empty");
		getLevel().add(3, sizeImage(empty));

		pipeVertical.setId("pipeVertical");
		getLevel().add(4, sizeImage(pipeVertical));

		empty.setId("empty");
		getLevel().add(5, sizeImage(empty));

		empty.setId("empty");
		getLevel().add(6, sizeImage(empty));

		empty.setId("empty");
		getLevel().add(7, sizeImage(empty));

		pipeVertical.setId("pipeVertical");
		getLevel().add(8, sizeImage(pipeVertical));

		emptyFree.setId("emptyFree");
		getLevel().add(9, sizeImage(emptyFree));

		empty.setId("empty");
		getLevel().add(10, sizeImage(empty));

		empty.setId("empty");
		getLevel().add(11, sizeImage(empty));

		curvediPipe01.setId("curvediPipe01");
		getLevel().add(12, sizeImage(curvediPipe01));

		pipeHorizontal.setId("pipeHorizontal");
		getLevel().add(13, sizeImage(pipeHorizontal));

		PipeStaticHorizontal.setId("PipeStaticHorizontal");

		getLevel().add(14, sizeImage(PipeStaticHorizontal));

		finishHorizontalLeft.setId("finishHorizontalLeft");
		getLevel().add(15, sizeImage(finishHorizontalLeft));

	}
	// LEVEL 2
	public void createLevel2(ArrayList<ImageView> level) {

		level.add(0, sizeImage(startVertical));
		level.add(1, null);
		level.add(2, null);
		level.add(3, null);
		level.add(4, sizeImage(pipeVertical));
		level.add(5, sizeImage(null));
		level.add(6, sizeImage(null));
		level.add(7, sizeImage(null));
		level.add(8, sizeImage(pipeVertical));
		level.add(9, sizeImage(null));
		level.add(10, sizeImage(null));
		level.add(11, sizeImage(null));
		level.add(12, sizeImage(curvediPipe01));
		level.add(13, sizeImage(pipeHorizontal));
		level.add(14, sizeImage(PipeStaticHorizontal));
		level.add(15, sizeImage(finishHorizontalLeft));

	}
	// LEVEL 3
	public void createLevel3(ArrayList<ImageView> level) {

		level.add(0, sizeImage(startVertical));
		level.add(1, sizeImage(null));
		level.add(2, sizeImage(null));
		level.add(3, sizeImage(null));
		level.add(4, sizeImage(pipeVertical));
		level.add(5, sizeImage(null));
		level.add(6, sizeImage(null));
		level.add(7, sizeImage(null));
		level.add(8, sizeImage(pipeVertical));
		level.add(9, sizeImage(null));
		level.add(10, sizeImage(null));
		level.add(11, sizeImage(null));
		level.add(12, sizeImage(curvediPipe01));
		level.add(13, sizeImage(pipeHorizontal));
		level.add(14, sizeImage(PipeStaticHorizontal));
		level.add(15, sizeImage(finishHorizontalLeft));

	}
	// LEVEL 4
	public void createLevel4(ArrayList<ImageView> level) {

		level.add(0, sizeImage(startVertical));
		level.add(1, sizeImage(null));
		level.add(2, sizeImage(null));
		level.add(3, sizeImage(null));
		level.add(4, sizeImage(PipeStaticVertical));
		level.add(5, sizeImage(null));
		level.add(6, sizeImage(null));
		level.add(7, sizeImage(finishVerticalDown));
		level.add(8, sizeImage(curvediPipe01));
		level.add(9, sizeImage(pipeHorizontal));
		level.add(10, sizeImage(pipeHorizontal));
		level.add(11, sizeImage(curvediPipe00));
		level.add(12, sizeImage(null));
		level.add(13, sizeImage(null));
		level.add(14, sizeImage(null));
		level.add(15, sizeImage(null));

	}
	// LEVEL 5
	public void createLevel5(ArrayList<ImageView> level) {

		level.add(0, sizeImage(startVertical));
		level.add(1, sizeImage(null));
		level.add(2, sizeImage(null));
		level.add(3, sizeImage(null));
		level.add(4, sizeImage(pipeVertical));
		level.add(5, sizeImage(null));
		level.add(6, sizeImage(null));
		level.add(7, sizeImage(finishVerticalDown));
		level.add(8, sizeImage(pipeStatic01));
		level.add(9, sizeImage(pipeHorizontal));
		level.add(10, sizeImage(pipeHorizontal));
		level.add(11, sizeImage(curvediPipe00));
		level.add(12, sizeImage(null));
		level.add(13, sizeImage(null));
		level.add(14, sizeImage(null));
		level.add(15, sizeImage(null));

	}
	// Getter and Setter Methos
	public ArrayList<ImageView> getLevel() {
		return level;
	}

	public void setLevel(ArrayList<ImageView> level) {
		this.level = level;
	}
}

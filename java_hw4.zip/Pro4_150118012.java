/*
 The program works for asking the user to enter two positive integer values: startPoint and endPoint. 
 The program will then find all numbers that fall between startPoint and  endPoint according to menu that I  prepared.
 
  EMINE CIG
  150118012
  
  */

import java.util.Scanner;

public class Pro4_150118012 {

	public static void main(String[] args) {
		while (true) {
			Scanner input=new Scanner (System.in);
			
			System.out.println("Enter a starting value: ");
			int startPoint = input.nextInt ();
			
			
			
			//An error message for warn user when user entered negative integer and prompts to user again starting value until enter right condition
			while  (startPoint<0 ) {
				System.out.println("You must enter positive integer ! .");
				System.out.println("Enter a starting value: ");
				startPoint = input.nextInt ();
		}
			System.out.println("Enter an ending value: ");			
			int endPoint = input.nextInt ();
			
			//An error message for warn user when user entered negative integer and prompted to user again ending value until enter right condition
			while  (endPoint<0 ) {
				System.out.println("You must enter positive integer ! .");
				System.out.println("Enter an ending value: ");
				endPoint = input.nextInt ();
		}
			//when user entered lower ending value than starting value , program prompt to user starting and ending value until enter right condition
			while (startPoint>endPoint) {
				System.out.println("Ending value must be greater than or equeal to starting value !.");
				System.out.println("Enter an ending value: ");
				endPoint = input.nextInt ();
				
			}			
			//Printed menu for user 
			System.out.println("Welcome to our Number Finder Program");
			
			System.out.println(" 1. Prime Numbers between"+startPoint+" and " +endPoint+
					"\n 2. Perfect Numbers between "+startPoint+" and "+ endPoint +
					"\n 3. Fibonacci between "+startPoint+" and "+ endPoint +
					"\n 4. Woodall between "+startPoint+" and "+ endPoint +
					"\n 5. Tau between "+startPoint+" and "+ endPoint +
					"\n 6. Smith between "+startPoint+" and "+ endPoint +
					"\n Please enter your menu chose (0 for exit )");
			
			//Chooses is entered from menu
			int choice = input.nextInt();
			
			//An error message for when user enter number out of range from menu and program prompts again 
			while (choice < 0 || choice >6) {
				   System.out.println("Your choice's interval is 0 to 6 from menu !");
				   System.out.println("Please enter your menu chose (0 for exit )");
				   choice = input.nextInt();
			}
		   //Method is run according to the user choose.
		   switch(choice) {
		   case 0:
			   System.out.println("See you ");
			   return;
		   case 1:
			   prime(startPoint,endPoint);
			   break;
		   case 2:
			   perfect(startPoint,endPoint);
			   break;
		   case 3:
			   fibonacci(startPoint,endPoint); 
			   break;
		   case 4:
			   woodall(startPoint,endPoint);
			   break;
		   case 5: 
			   tau(startPoint,endPoint);
			   break;
		   case 6:
			   smith(startPoint,endPoint);
			   break;
		   default:
			   		   
		   }		      
		   
		   System.out.println();
		   //Asked to user for continue the program 
		System.out.println("Do you want to find new numbers (Y/N)");
		String response= input.next();
		
		if (response.toUpperCase().equals("N")) {
			System.out.println("See you ");
			break;
		}
		else if (response.toUpperCase().equals("Y"))
			continue;
		//An error message for when different response from 'Y' and 'N' is entered
		else
			System.out.println("You must enter Y(YES) or N(NO) !");
			break;
		}
			
	}
	//EACH METHOD FOR DİFFERENT TYPE OF NUMBER
	
	// PRIME NUMBER 
	
    public static void prime (int  startPoint,int endPoint) {  	
    	//Assign a variable for calculate number of printed number .When no number does not printed gives a error message.
    	int count=0;
    	
        //Loop continue from start point until endPoint with increasing number's value 	
    	for (int number=startPoint;number<=endPoint;number++) {
    		
    		// Removed 0 and 1 in rage  due to be not prime numbers
    		if (number==0||number==1)
    			continue;
    		
    		//Assumed number is prime 
    		boolean isPrime=true;
    		
    		//Divisor number increase  from 2 until numbers value  and checked whether isPrime false or not 
    		for (int divisor=2;divisor<number ;divisor ++) {
    			if (number%divisor==0)
    				isPrime=false;
    		}
    		//When number is prime .It printed and count increases 
    		if (isPrime) {
    			System.out.print(number+" ");
    		    count++;
    		}   	}
    	//If no number does not print , gives a error message 
    	if (count==0)
    		System.out.println("No prime numbers found between "+startPoint+" and "+endPoint);
   }    
    
    // PERFECT NUMBER
    
    public static void perfect (int startPoint,int endPoint) {
    	//Assign a variable for calculate number of printed number .When no number does not printed gives a error message.
    	int count=0;
    	
    	//Loop continue from start point until endPoint with increasing number's value
    	for (int number=startPoint ; number<=endPoint ; number++) {
    		
    		//Removed o as 0 is not a perfect number
    		if (number==0)
    			continue;
    		
    		//Assigned a variable to collect sum of the sum of all its proper divisors
    		int sum=0;
    		//Divisor number increase  from 1 until number's value  and checked whether number is divisible .If divisible add it to sum
    		for (int divisor=1 ; divisor < number ; divisor ++) {
    			if (number%divisor==0)
    				sum+=divisor;
    		}
    		//According to equality 'number' to 'sum' , number prints and count increases
    		if (number==sum) {
    			System.out.print(number+" ");
    		    count++;
		}  	}
    	//If no number does not print , gives a error message 
    	if (count==0)
    		System.out.println("No perfect numbers found between "+startPoint+" and "+endPoint);
    }
    
    //FIBONACCİ NUMBERS
    public static void fibonacci (int startPoint,int endPoint) {
    	//Assign a variable for calculate number of printed number.When no number does not printed gives a error message.
    	int count =0;
    	//Assigned variables for first , second and temporary value.
    	int n= 0;
    	int n1=0;
    	int n2=1;
    	
    	if (startPoint==0) {
			System.out.print("0"+" 1"+" ");
            count++;
    	}
    	
    	else if (startPoint==1) {
    		System.out.print("1"+" ");
            count++;
    	}
    	//Loop continue from 0 until endPoint with increasing number's value 	
    	for (int number=0 ; number<endPoint ;number++ ) {
    		n=n2+n1;
    	    n1=n2;
    	    n2=n;
    	//If number is in range . it can print and count increases
    	    if(startPoint <=n && n<=endPoint) {
    	    	System.out.print(n+" ");
    	        count++;	
        	    	}
    	    	}
    	 //If no number does not print , gives a error message 
    	 if (count==0)
    	     System.out.println("No fibonacci numbers found between "+startPoint+" and "+endPoint);
    }	
    
    	 //WOODALL NUMBERS 
    	       
	 public static void woodall(int startPoint,int endPoint) { 
		 
		//Assign a variable for calculate number of printed number .When no number does not printed gives a error message.
         int count=0;
      
         //Loop continue from n is 1 until n is used to reach end point value with increasing n's value
    	 for ( int n=1 ; ((Math.pow(2, n)*n)-1)<=endPoint ; n++) {
    		 
    		 int number= (int) (((Math.pow(2, n))*n)-1);
    		 
    		 //If number is smaller than or equal to  start point . it can print and count increases
    		 if (number>=startPoint) {
    		     System.out.print(number+" ");
    		     count++;   		 
    		}  	 }
	
    	//If no number does not print , gives a error message 
    	 if (count==0)
     		System.out.println("No woodall numbers found between "+startPoint+" and "+endPoint);
}
        //TAU NUMBERS
    
    public static void tau(int startPoint,int endPoint) { 
    	//Assign a variable for calculate number of printed number .When no number does not printed gives a error message.
    	int count=0;
    	//Loop continue from start point until endPoint with increasing number's value
    	for (int number=startPoint;number<=endPoint;number++) {
    		
    		int countOfDivisor=0;
    		//Removed 0 due to be not a tau number
    		if (number==0) 
				continue;
    		//Loop continue from 1 until equal to instantaneous number's value with increasing divisor's value
    		for (int divisor=1 ; divisor <= number ; divisor ++) {
    	    //Calculated number of divisors
    			if (number%divisor==0) 
    				countOfDivisor++;	
    		}
    		// Checked divisibility  of number to counOfDivisor 
    		if (number%countOfDivisor==0) {
    			System.out.print(number+" ");
    		    count++;
    		}
    			
    	}
    	//If no number does not print , gives a error message 
    	if (count==0)
    		System.out.println("No tau numbers found between "+startPoint+" and "+endPoint);
    }
    
    //Smith Number
    
	 public static void smith(int startPoint,int endPoint) { 
		//Assign a variable for calculate number of printed number .When no number does not printed gives a error message.
		    int count=0;
		  //Loop continue from start point until endPoint with increasing number's value
	    	for (int number=startPoint ; number<=endPoint ; number++) {
	    		
	    		//Removed 0 due to be not a smith number
	    		if (number==0) 
					continue;
	    		
	    		int sumOfDivisor =0;
	    		int sumOfDigit=0;
	    		//Assigned a temporary value to protect number's value
	    		int temp =number;
	    		
	    		// Sum of digit of number 
	    		while(temp!=0) {
					sumOfDigit+=temp%10;
					temp/=10;
	    		}
	    		//Assigned a new temporary value to protect number's value
	    		int tempNumber=number;
	    		//Loop continue 2 until number'svalue with increasing divisor's value
	    		for (int divisor=2 ; divisor < number ; divisor ++) {
	    			//Checked divisibility  of tempNumber to divisor 
	    			if (tempNumber%divisor==0) {
	    				
	   	                     //Loop continue until not equal to remain to 0
	            			while(tempNumber%divisor==0) {
	            				
	            				//Assigned divisor to a temporary to protect its value
	            				int tempDivisor=divisor;
	            				
	            				//Loop for collect sum of divisor digits
	            				while(tempDivisor!=0) {
	            					sumOfDivisor+=tempDivisor%10;
	            					tempDivisor/=10;			
	            				}
	            				//Decreased tempNumbers value 
	            				tempNumber/=divisor ;
	            			}}}	
	    	//Checked equality of sumOfDivisor to sumOfDivisor
	        if (sumOfDivisor==sumOfDigit) {
	        	System.out.print(number+" ");
	            count++;
	        }
	            			}
	    	//If no number does not print , gives a error message 
	    	if (count==0)
	    		System.out.println("No smith numbers found between "+startPoint+" and "+endPoint);
	    	}
}
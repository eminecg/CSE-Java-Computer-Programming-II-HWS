import java.util.Scanner;
/*
EMINE CIG
150118012

Program is a two-dimensional Grid Game.There is a person(X) and multiple items(*). 
The user will move the person in the game with the right (R), left (L), down (D) and up (U) keys
Items placed into the cell randomly. Person start cell point is (0,0) and The aim of this person is to collect all the items with in limited number of movement. 

*/

public class Pro5_1_150118012 {
	public static void main (String[] args) {
		
		System.out.println("WELCOME TO THE GRID GAME ");
		//Prompts to enter number of size of grid area from the user 
		System.out.println("Please enter the Grid size : ");
		
		Scanner input =new Scanner (System.in);
		int N=input.nextInt();
		//An error message for when the user enter negative or zero value for grid size and again prompts the input for it 
		while(N<=0) {
        	System.out.println("Please enter pozitive number for grid size  ! ");
        	System.out.println("Please enter the Grid size : "); 
        	N=input.nextInt();
        }
		
		
		//Declares, creates and initializes an array with grid size
		int [][] grid=new int[N][N];
		
		// Create current position values 
		int x= 0;
	    int x1=0;
		int y=0;
		int y1=0;
		// Create a variable number of movement in proportion to grid size 
		int  movement = (int)(2.5*N);
		
		//Number of collected item
		int countitem=0;
		//Message for beginning to game 
		System.out.println("--Hello "+N+"x"+N+" Grid Game--");
		
		// Beginning point for the user 
		grid[y1][x1]=2;
		
		// Assigned in while loop randomly item in array indexes
		while (countitem<N/2) {			
			// Random array indexes
			int i = (int )(Math.random()*N);
			int j=(int )(Math.random()*N);
			
			//If the determined point randomly has not same special value such as 5(used for item)and 2 (used for user position), item is assigned in it .
			if (grid[i][j]!=5 && grid[i][j]!=2) {
			     grid[i][j]=5;
			     countitem++;			
			}}
		    
		   // Prints grid area with items(*) , user(X) ,used before cells(+) and with not used before cells ( ) until movement become 0 .
		    while (0<movement) {
		    	
		    // for loops is used to get indexes respectively	
			for (int i =0;i<grid.length;i++) {
				// Prints begin wall
				System.out.print("|");
				for (int j=0;j<grid.length;j++) {
					
					//Matches index value with its character and prints
					switch(grid[i][j]) {
					case 0:
						System.out.print(" ");	
						break;
					case 1:
						System.out.print("+");	
						break;
					case 2:
						System.out.print("X");	
						break;
					case 5:
						System.out.print("*");
						break;						
					}				
				
			}   //Prints end wall
				System.out.print("|");
				System.out.println();
		}
			//If all items is collected from user , prints message 
			if (countitem==0) {
				System.out.println("*** YOU  WIN :) ***");
				return;
				
			}	
			// Prints  number of remain movement , current position and directions for moving 
			System.out.println("Moves : "+movement+"         "+"Current cells : " + "(" +x+ "," +y+ ")" );
			System.out.println("Choose Your Direction ( R , L , D , U ) : "); 
			String direction = input.next().toUpperCase();
			
			//If the user enter not possible direction, gives a message and get prompts input again until right direction is entered 
	        while(!(direction.equals("R")||direction.equals("L")||direction.equals("D")||direction.equals("U"))) {
	        	System.out.println("Please enter possible direction ! ");
	        	System.out.println("Choose Your Direction ( R , L , D , U ) : "); 
	        	direction = input.next().toUpperCase();
	        }
								
		   //Depending on type of direction , user(X) is moved  and movement number decreases 	
			switch (direction) {
			
			case "R":				
				// Checks whether user is in front of  the end wall or next step was used before or not 
				if (x+1<grid.length && grid[y][x+1]!=1) {
					if (grid[y][x+1]==5) {
						countitem--;
						
					}
					//Current position point of user is shifted previous.
					x1=x+1;
					grid[y][x]=1;
					grid[y1][x1]=2;
					movement--;
					
				}
				break;
		        
			case "L":	
				// Checks whether user is in front of the initial wall or next step was used before or not 
				if (0<=x-1&& grid[y][x-1]!=1) {
					if (grid[y][x-1]==5) {
						countitem--;
						
					}
					//Current position point of user is shifted previous.Assigns new value current and previous position 
					grid[y][x]=1;				
					x1=x-1;
					grid[y1][x1]=2;
					movement--;
				}
				break;
				
			case "U":
				// Checks whether user is very close to out of grid area or next step was used before or not
				if (0<=y-1&& grid[y-1][x]!=1) {
					if (grid[y-1][x]==5) {
						countitem--;
						
					}
					//Current position point of user is shifted previous.Assigns new value current and previous position 
					y1=y-1;
					grid[y][x]=1;
					grid[y1][x1]=2;
					movement--;
				}
				
				 break;
				 
			case "D":
				// Checks whether user is very close to out of grid area or next step was used before or not
				if (y+1<grid.length&& grid[y+1][x]!=1) {
					if (grid[y+1][x]==5) {
						countitem--;
						
					}
					//Current position point of user is shifted previous.Assigns new value current and previous position 
					y1=y+1;
					grid[y][x]=1;
					grid[y1][x1]=2;
					movement--;
				}
					
		        break;
		        
		    default:
		    	System.out.println("Please enter current direction !");
		  
			}
			if (movement==0) {
				System.out.println("--- GAME OVER :( ---");
				
			}
			//New position points is become current
	        x=x1;
		    y=y1;
			}
}
}
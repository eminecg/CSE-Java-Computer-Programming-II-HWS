import java.util.Scanner;
/*
 EMINE CIG
 150118012
 Program works for testing whether a two-dimensional list has string keyword which is prompted from user , either horizontally, vertically, or diagonally .
 
 */

public class Pro5_2_150118012 {
    public static void main (String[] args) {
    	// Prompts to enter number of row and columns from the user 
    	System.out.println("Please enter the number of rows :");
    	
    	Scanner input =new Scanner (System.in);
    	int rows =input.nextInt();
    	
    	//An error message for when the user enter negative or zero value for rows and again prompts the input for it 
    	while(rows<=0) {
        	System.out.println("Please enter pozitive number for rows  ! ");
        	System.out.println("Please enter the number of rows : "); 
        	rows =input.nextInt();
        }
		
    	
    	System.out.println("Please enter the number of columns :");
    	int columns =input.nextInt();
    	
    	//An error message for when the user enter negative or zero value for columns and again prompts the input for it 
    	while(columns<=0) {
        	System.out.println("Please enter pozitive number for columns  ! ");
        	System.out.println("Please enter the number of columns:  "); 
        	columns =input.nextInt();
        }
		
 
    	
    	//Creates and initializes a two dimensional array for list, its parameters obtained from input.
    	String[][] list =new String[rows][columns];
    	
    	//Loop is used for get random string values from letters between �A� to �Z� and �0� to �9� and assign them in list .
    	for (int i=0;i<list.length;i++) {
    		for (int j=0;j<list[i].length;j++) {
    			
    		//Letters between �A� to �Z� and �0� to �9�	
    		String letters ="QWERTYUIOPASDFGHJKLZXCVBNM1234567890";
    		int index =(int)( Math.random()*(36));
    		list[i][j]=Character.toString((letters.charAt(index)));   		
    			
    		}  		
    	}    	
    	//Loop is used for printing list by getting values from indexes respectively    	
    	for (int i=0;i<list.length;i++) {
    		for (int j=0;j<list[i].length;j++) {
    			System.out.print(list[i][j]+" ");   			

    		}
    		System.out.println();
    		}
    	//Creates a boolean for assume keyword is not found     	
    	boolean iskey =false;  
    	
    	//Keyword is prompted from user and then is getting  input .
    	 System.out.println("Please enter the keyword : ");   	
    	 String keyword=input.next();
    	 
    	 
    	 // An error message ,when user wrongly enter a keyword  which has greater size than both size of rows and columns 
    	 while (keyword.length()>Math.max(list.length,list[0].length)){
    		 System.out.println("You can not enter a keyword has greater size than both size of rows and columns !");
    		 System.out.println("Please enter the possible keyword : "); 
    		 keyword=input.next();
    	 }
    	 //Program can run upper or lower case letter
    	 keyword=keyword.toUpperCase();
    	 //Keyword's letters is assigned in a list to be able to compare each element of list 
    	 String[] keylist =new String[keyword.length()] ;    	 
    	 for (int i=0;i<keyword.length();i++) {
    		 
    		 //Keyword's letters is obtained by using charAt() and converted to String due to be same type of keyword list 
    		 keylist[i]=Character.toString(keyword.charAt(i));   
    	     	}
    	 
        //"For loops" is used  to get references respectively for lists.
    	for (int i =0; i<list.length;i++)	{
    		   		
    		for (int j=0; j<list[i].length;j++) {
    			
    			//When the program find first match with first element of key list with list ,methods run 
    			if(list[i][j].equals(keylist[0])) {
    				
    		       // All methods compares each element on key list with list to find keyword on either horizontally, vertically, or diagonally
	    			forward(i,j,keylist,list);  	    			
	    			backward(i,j,keylist,list);
	    			down(i,j,keylist,list);
	    			up(i,j,keylist,list);
	    			diagonallyrightdown(i,j,keylist,list);
	    			diagonallyleftdown(i,j,keylist,list);
	    			diagonallyrightup(i,j,keylist,list);
	    			diagonallyleftup(i,j,keylist,list);
	    			
	    	}}}
    	//Examines whether keyword is found or not on list with using boolean .If it is not found , printed FALSE on the console
    	if (!iskey)
    		System.out.println("FALSE");
    		
    	}
    //Methods for examine keyword  on list 
    
    // METHOD OF FORWARD ON HORIZANTALLY  
    public static boolean forward(int i, int j,String[] keylist,String [][] list){
    	
    // Creates a variable to count how much letters is match when comparing lists 
   	int count =0;
   	
    boolean iskey =false;
    
   	 //Loop is used for examine matched letters between list and increases count variable 
   	 for (int x=j ; x<(keylist.length+j) && x< list[i].length;x++) {
   			if(list[i][x].equals(keylist[x-j])) {	    						
   				count++;	
   			}
   	}
   	//Number of elements in key list is matched with list element , program print TRUE on console 
   	if (count ==keylist.length) {
   		iskey=true;   	
   		System.out.println("TRUE");
   		System.exit(46);
   	}
   	
   	return iskey;
   	}
     //METHOD FOR  BACKWARD ON HORIZANTALLY 
    public static boolean backward(int i, int j,String[] keylist,String[][] list){ 
    	// Creates a variable to count how much letters is match when comparing lists 
    	int count =0;
      	boolean iskey =false;
      	 //Loop is used for examine matched letters between list and increases count variable
    	for(  int x=j;  x>j-keylist.length && x>=0 ;x--  ) {  // POSSIBLE ERROR 
			if(list[i][x].equals(keylist[j-x])) {
				count++;	
			}
		}
    	//Number of elements in key list is matched with list element , program print TRUE on console
		if (count ==keylist.length) {			
			iskey=true;	
			System.out.println("TRUE");
			System.exit(46);
		
		}
	return iskey;
   	
    }
    //METHOD FOR  DOWNWARD ON VERTICALLY
   	public static boolean down(int i, int j,String[] keylist,String[][] list){ 
   	    // Creates a variable to count how much letters is match when comparing lists
    	int count =0;
      	boolean iskey =false;
      //Loop is used for examine matched letters between list and increases count variable 
      	for (int x=i ; x<(keylist.length+i) && x< list.length ; x++) {
			if(list[x][j].equals(keylist[x-i])) {	    						
				count++;	
			}
	}
      //Number of elements in key list is matched with list element , program print TRUE on console
	if (count ==keylist.length) {
		
		iskey=true;
		System.out.println("TRUE");
		System.exit(46);
	}
	
    return iskey;
    
    }
   	 
    //METHOD FOR  UPWARD ON VERTICALLY
   	public static boolean up(int i, int j,String[] keylist,String[][] list){
   	    // Creates a variable to count how much letters is match when comparing lists
    	int count =0;
      	boolean iskey =false;
      //Loop is used for examine matched letters between list and increases count variable 
      	for(  int x=i;  x>i-keylist.length && x>=0 ;x--  ) {
			if(list[x][j].equals(keylist[i-x])) {
				count++;	
			}
		}
        //Number of elements in key list is matched with list element , program print TRUE on console
		if (count ==keylist.length) {			
			iskey=true;
			System.out.println("TRUE");
			System.exit(46);
		
		}
		
    return iskey;
   	
    }
    //METHOD FOR  RIGHT DOWN DIAGONALLY
	public static boolean diagonallyrightdown(int i, int j,String[] keylist,String[][] list){ 
		// Creates a variable to count how much letters is match when comparing lists
		int count =0;
	    boolean iskey =false;
	     //Loop is used for examine matched letters between list and increases count variable 
	   	 for (int x=j ,y =i; x<(keylist.length+j) && x< list[i].length&& y<list.length;x++,y++) {
	   			if(list[y][x].equals(keylist[x-j])) {	    						
	   				count++;	
	   			}
	   	}
	   //Number of elements in key list is matched with list element , program print TRUE on console
	   	if (count ==keylist.length) {
	   		iskey=true;   	
	   		System.out.println("TRUE");
	   		System.exit(46);
	   	}
	   	
	   	return iskey;
	   	}
	//METHOD FOR  LEFT DOWN DIAGONALLY
	public static boolean diagonallyleftdown(int i, int j,String[] keylist,String[][] list){
		// Creates a variable to count how much letters is match when comparing lists
		int count =0;
	    boolean iskey =false;
	     //Loop is used for examine matched letters between list and increases count variable 
	   	 for (int x=j ,y =i; x>j-keylist.length&& x>=0  && y<(keylist.length+i) && y< list.length;x--,y++) {
	   			if(list[y][x].equals(keylist[y-i])) {	    						
	   				count++;	
	   			}
	   	}
	   //Number of elements in key list is matched with list element , program print TRUE on console
	   	if (count ==keylist.length) {
	   		iskey=true;   	
	   		System.out.println("TRUE");
	   		System.exit(46);
	   	}
	   	
	   	return iskey;
	   	}
	//METHOD FOR  RIGHT UP DIAGONALLY
	public static boolean diagonallyrightup(int i, int j,String[] keylist,String[][] list){ 
		int count =0;
	    boolean iskey =false;
	     //Loop is used for examine matched letters between list and increases count variable 
	   	 for (int x=j ,y =i; x<(keylist.length+j) && x< list[i].length && y>i-keylist.length && y>=0;x++,y--) {
	   			if(list[y][x].equals(keylist[x-j])) {	    						
	   				count++;	
	   			}
	   	}
	   //Number of elements in key list is matched with list element , program print TRUE on console
	   	if (count ==keylist.length) {
	   		iskey=true;   	
	   		System.out.println("TRUE");
	   		System.exit(46);
	   	}
	   	
	   	return iskey;
	   	}
	//METHOD FOR LEFT UP DIAGONALLY
	public static boolean diagonallyleftup(int i, int j,String[] keylist,String[][] list){ 
		int count =0;
	    boolean iskey =false;
	     //Loop is used for examine matched letters between list and increases count variable 
	   	 for (int x=j ,y =i; x>j-keylist.length && x>=0&& y>i-keylist.length && y>=0;x--,y--) {
	   			if(list[y][x].equals(keylist[j-x])) {	    						
	   				count++;	
	   			}
	   	}
	   //Number of elements in key list is matched with list element , program print TRUE on console
	   	if (count ==keylist.length) {
	   		iskey=true;   	
	   		System.out.println("TRUE");
	   		System.exit(46);
	   	}
	   	
	   	return iskey;
	   	}	
	}
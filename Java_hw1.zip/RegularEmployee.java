import java.util.Calendar;

public class RegularEmployee extends Employee {

    private double performanceScore;
    private double bonus;



    public RegularEmployee(int id, String firstname, String lastname, String gender, Calendar birtDate, String maritalStatus, String hasDriverLisence, double salary, Calendar hireDate, Department department, double performanceScore) {
        super(id, firstname, lastname, gender, birtDate, maritalStatus, hasDriverLisence, salary, hireDate, department);
        this.performanceScore = performanceScore;
        //System.out.println(this);
    }




    public RegularEmployee(Employee employee, double perfScore){

        super(employee.getId(),employee.getFirstname(),employee.getLastname(),employee.getGender(),employee.getBirtDate(),employee.getMaritalStatus(),employee.getHasDriverLisence(),employee.getSalary(),employee.getHireDate(),employee.getDepartment());

        this.performanceScore=perfScore;

    }

    public double getPerformanceScore() {
        return performanceScore;
    }

    public void setPerformanceScore(double performanceScore) {
        this.performanceScore = performanceScore;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    @Override
    public String toString() {
        return "                       RegularEmployee[" +
                "performanceScore=" + performanceScore +
                ", bonus=" + bonus +

                ']';
    }
    public  String getPerson(){
        return super.toString();
    }





}

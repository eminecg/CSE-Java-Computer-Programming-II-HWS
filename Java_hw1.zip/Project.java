import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Project {

    private String projectName;
    private java.util.Calendar startDate;
    private boolean state;

    public Project(String projectName, Calendar startDate, String state) {
        this.projectName = projectName;
        this.startDate = startDate;
        this.setState(state);
    }


    public void setState(String state) {
        if(state.equals("Open"))
            this.state=true;
        else if (state.equals("Close")){
            this.state=false;
        }
        //
        else{
            throw new IllegalArgumentException("Gender type is not valid ");
        }

    }

    public String  getState() {
        if(state)
            return "Open";
        else if (!state)
            return "Close";
        //
        else{
            throw new IllegalArgumentException("give a message !");
        }
    }


    public void  close () {
     if(state){
         System.exit(1);

     }

    }

    // getter setter to string methods
    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }
//
    public String   getStartDate2() {


        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

return format.format(startDate.getTime());
    }

    public Calendar getStartDate(){
        return startDate;
    }


    public void setStartDate(Calendar startDate) {
        this.startDate = startDate;
    }



    @Override
    public String toString() {
        return "                      Project[" +
                "projectName='" + projectName + '\'' +
                ", startDate=" + getStartDate2() +
                ", state=" + state +
                ']';
    }
}

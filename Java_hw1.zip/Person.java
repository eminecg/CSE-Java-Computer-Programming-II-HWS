
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Person {

    private int  id;
    private  String firstname;
    private  String lastname;
    private byte gender;
    private java.util.Calendar birtDate;
    private byte maritalStatus;
    private  boolean hasDriverLisence;

    public Person(int id, String firstname, String lastname, String gender, Calendar birtDate, String maritalStatus, String hasDriverLisence) {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.birtDate = birtDate;
        setGender(gender);
        setMaritalStatus(maritalStatus);
        setHasDriverLisence(hasDriverLisence);
    }

    public void setGender(String gender) {
        if(gender.equals("Man"))
            this.gender=1;

        else if (gender.equals("Woman"))
            this.gender=2;
        else{
            throw new IllegalArgumentException("Gender type is not valid ");
        }
    }


    public String getGender()  {
        if(gender==1)
            return "Man";
        else if(gender==2)
            return "Woman";
        else{
           throw new IllegalArgumentException("Gender type is not valid ");
        }
    }

    public void setMaritalStatus(String maritalStatus) {
        if(maritalStatus.equals("Single"))
            this.maritalStatus=1;

        else if (maritalStatus.equals("Married"))
            this.maritalStatus=2;

        else{
            throw new IllegalArgumentException("Martial status type is not valid ");
        }
    }


    public String getMaritalStatus() {
        if(maritalStatus==1)
            return "Single";
        else if(maritalStatus==2)
            return "Married";
        else{
            throw new IllegalArgumentException(" Martial status type is not valid ");
        }
    }

    public void setHasDriverLisence(String hasDriverLisence) {
        if(hasDriverLisence.equals("Yes"))
            this.hasDriverLisence=true;

        else if (hasDriverLisence.equals("No"))
            this.hasDriverLisence=false;

        else{
            throw new IllegalArgumentException(" Driver lisence type is not valid ");
        }
    }

    public String getHasDriverLisence() {

        if(hasDriverLisence)
            return "Yes";

        else if(!hasDriverLisence)
            return "No";
        else{
            throw new IllegalArgumentException(" Driver lisence type is not valid ");
        }
    }


//   to string methodunda tam olarak ne yapıcaz ?
    @Override
    public String toString() {

        return "Person Info [" +
                "id=" + id +
                ", firstname='" + firstname + '\'' +
                ", lastname='" + lastname + '\'' +
                ", gender=" + getGender() +

                ']';
    }
    //

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Calendar getBirtDate() {
        return birtDate;
    }

    public String   getBirtDatetemp() {


        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

        return format.format(birtDate.getTime());
    }

    public void setBirtDate(Calendar birtDate) {
        this.birtDate = birtDate;
    }

    public  String getPerson(){
        return super.toString();
    }




}

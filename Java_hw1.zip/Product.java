import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Product {

    private String productName ;

    private java.util.Calendar saleDate;
    private  double price;

    public Product(String productName, Calendar saleDate, double price) {
        this.productName = productName;
        this.saleDate = saleDate;
        this.price = price;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Calendar getSaleDate() {
        return saleDate;
    }
    public String   getSaleDatetemp() {


        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

        return format.format(saleDate.getTime());
    }


    public void setSaleDate(Calendar saleDate) {
        this.saleDate = saleDate;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    public void date(){

    }

    @Override
    public String toString() {
        return "Product{" +
                "productName='" + productName + '\'' +
                ", saleDate=" + getSaleDatetemp() +
                ", price=" + price +
                '}';
    }
}

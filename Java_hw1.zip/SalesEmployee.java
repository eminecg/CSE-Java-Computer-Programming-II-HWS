import java.util.ArrayList;
import java.util.Calendar;

public class SalesEmployee extends RegularEmployee {

    private ArrayList<Product> sales= new ArrayList<Product>();

    public static int numberOfSalesEmployees;

    public SalesEmployee(int id, String firstname, String lastname, String gender, Calendar birtDate, String maritalStatus, String hasDriverLisence, double salary, Calendar hireDate, Department department, double performanceScore, ArrayList<Product> s) {
        super(id, firstname, lastname, gender, birtDate, maritalStatus, hasDriverLisence, salary, hireDate, department, performanceScore);
        this.sales = s;
        numberOfSalesEmployees++;


    }

    public SalesEmployee(RegularEmployee re, ArrayList<Product> sales){
        super(re.getId(),re.getFirstname(),re.getLastname(),re.getGender(),re.getBirtDate(),re.getMaritalStatus(),re.getHasDriverLisence(),re.getSalary(),re.getHireDate(),re.getDepartment(),re.getPerformanceScore());
        this.sales=sales;
        numberOfSalesEmployees++;


    }
    public boolean addSale(Product s) {

       return sales.add(s);


    }
    public  boolean removeSale(Product s){
        return sales.remove(s);


    }

    public ArrayList<Product> getSales() {
        return sales;
    }

    public void setSales(ArrayList<Product> sales) {
        this.sales=  sales;
    }

    @Override
    public String toString() {
        return "SalesEmployee{" +
                "sales=" + sales +
                ", numberOfSalesEmployees=" + numberOfSalesEmployees +
                ", numberOfEmployees=" + numberOfEmployees +
                '}';
    }
}

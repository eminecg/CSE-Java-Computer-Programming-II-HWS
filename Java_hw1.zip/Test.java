//Emine Çığ
//150118012

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


import java.util.Calendar;
import java.util.Scanner;



public class Test {
    public static void main(String[] args) throws Exception {

        File file = new File("input.txt");
        File fileo = new File("output.txt");
        Scanner input = new Scanner(file);
        java.io.PrintWriter output = new java.io.PrintWriter(fileo);

        ArrayList<Person> personArrayList = new ArrayList<Person>();
        ArrayList<Customer> customerArrayList = new ArrayList<Customer>();
        ArrayList<Manager> managerArrayList = new ArrayList<Manager>();
        ArrayList<RegularEmployee> regularEmployeeArrayList = new ArrayList<RegularEmployee>();
        ArrayList<SalesEmployee> salesEmployeeArrayList = new ArrayList<SalesEmployee>();
        ArrayList<Developer> developerArrayList = new ArrayList<Developer>();
        ArrayList<Project> projectArrayList = new ArrayList<Project>();
        ArrayList<Department> departmentArrayList = new ArrayList<Department>();
        ArrayList<Product> productArrayList = new ArrayList<Product>();
        ArrayList<Employee> employeeArrayList = new ArrayList<Employee>();


        while (input.hasNextLine()) {

            String line = input.nextLine();
            String[] data = line.split(" ");

            Calendar time = Calendar.getInstance();
            SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

            if (data[0].equals("Department")) {

                int id = Integer.parseInt(data[1]);
                String name = data[2];

                departmentArrayList.add(new Department(id, name));

            }


            if (data[0].equals("Project")) {


                String name = data[1];


                time.setTime(format.parse(data[2]));
                String state = data[3];

                projectArrayList.add(new Project(name, time, state));


            }


            if (data[0].equals("Product")) {

                String name = data[1];


                //time.setTime(format.parse(data[2]));
                int price = Integer.parseInt(data[3]);

                productArrayList.add(new Product(name,time, price));


            }

            if (data[0].equals("Person")) {
                int id = Integer.parseInt(data[3]);
                String firstname = data[1];
                String surname = data[2];
                String gender = data[4];
                time.setTime(format.parse(data[5]));
                String martialStatus = data[6];
                String hasDriverLicence = data[7];

                personArrayList.add(new Person(id, firstname, surname, gender, time, martialStatus, hasDriverLicence));

            }

            if (data[0].equals("Employee")) {

                int id = Integer.parseInt(data[1]);
                double  salary = Integer.parseInt(data[2]);

                time.setTime(format.parse(data[3]));
//?
                int i;
                for ( i = 0; i < personArrayList.size(); i++ ) {

                    if (personArrayList.get(i).getId() == id) {
                        break;


                    }

                }
                int j;
                for (  j = 0; j < departmentArrayList.size(); j++ ) {
                    if(departmentArrayList.get(j).getDepartmentName().equals(data[4])){
                        break;
                    }
                }
                    employeeArrayList.add(new Employee(personArrayList.get(i), salary, time, departmentArrayList.get(j)));

            }

            if (data[0].equals("RegularEmployee")) {

                int id = Integer.parseInt(data[1]);
                int perfScore = Integer.parseInt(data[2]);

                for ( int i = 0; i < employeeArrayList.size(); i++ ) {

                    if (employeeArrayList.get(i).getId() == id) {
                        regularEmployeeArrayList.add(new RegularEmployee(employeeArrayList.get(i), perfScore));
                        break;
                    }
                }
            }


            if (data[0].equals("Developer")) {

                int id = Integer.parseInt(data[1]);
                ArrayList<Project> tempList = new ArrayList<Project>();


                for ( int p = 2; p < data.length; p++ ) {
                    for ( int j = 0; j < projectArrayList.size(); j++ ) {
                        if (projectArrayList.get(j).getProjectName().equals(data[p])) {
                            tempList.add(projectArrayList.get(j));

                        }
                    }

                }
                int i;
                for ( i = 0; i < regularEmployeeArrayList.size(); i++ ) {
                    if (regularEmployeeArrayList.get(i).getId() == id) {
                        developerArrayList.add(new Developer(regularEmployeeArrayList.get(i), tempList));

                    }
                }
            }


            if (data[0].equals("Customer")) {

                int id = Integer.parseInt(data[1]);
                ArrayList<Product> tempList = new ArrayList<Product>();


                for ( int p = 2; p < data.length; p++ ) {
                    for ( int j = 0; j < productArrayList.size(); j++ ) {
                        if (productArrayList.get(j).getProductName().equals(data[p])) {
                            tempList.add(productArrayList.get(j));

                        }
                    }

                }
                int i;
                for ( i = 0; i < personArrayList.size(); i++ ) {
                    if (personArrayList.get(i).getId() == id) {
                        customerArrayList.add(new Customer(personArrayList.get(i), tempList));

                    }

                }
            }
            if (data[0].equals("Manager")) {


                int id = Integer.parseInt(data[1]);

                int bonusBudget = Integer.parseInt(data[2]);


                for ( int i = 0; i < employeeArrayList.size(); i++ ) {

                    if (employeeArrayList.get(i).getId() == id) {

                        managerArrayList.add(new Manager(employeeArrayList.get(i), bonusBudget));

                    }
                }


            }


            if (data[0].equals("SalesEmployee")) {
                int id = Integer.parseInt(data[1]);

                ArrayList<Product> tempList = new ArrayList<Product>();

                for ( int p = 2; p < data.length; p++ ) {
                    for ( int j = 0; j < productArrayList.size(); j++ ) {
                        if (productArrayList.get(j).getProductName().equals(data[p])) {
                            tempList.add(productArrayList.get(j));
                        }
                    }
                }

                int i;
                for ( i = 0; i < regularEmployeeArrayList.size(); i++ ) {
                    if (regularEmployeeArrayList.get(i).getId() == id) {
                        salesEmployeeArrayList.add(new SalesEmployee(regularEmployeeArrayList.get(i), tempList));

                    }
                }
            }


        }
        // adding  regular employee to array list
        for ( int i = 0; i < regularEmployeeArrayList.size(); i++ ) {

            for ( int j = 0; j < managerArrayList.size(); j++ ) {

                if (managerArrayList.get(j).getDepartment().equals(regularEmployeeArrayList.get(i).getDepartment())) {
                    // adding employee to employee arrayList
                    managerArrayList.get(j).    addEmployee(regularEmployeeArrayList.get(i));
                }
            }
        }





        for ( int i = 0; i < managerArrayList.size(); i++ ) {
            managerArrayList.get(i).distributeBonusBudget();

        }

        for ( int i = 0; i < managerArrayList.size(); i++ ) {
            managerArrayList.get(i).raiseSalary(0.2);

        }
        for ( int i = 0; i < regularEmployeeArrayList.size(); i++ ) {
            regularEmployeeArrayList.get(i).raiseSalary(0.3);

        }
        for ( int i = 0; i < developerArrayList.size(); i++ ) {
            developerArrayList.get(i).raiseSalary(0.23);
        }
        for ( int i = 0; i < salesEmployeeArrayList.size(); i++ ) {
            salesEmployeeArrayList.get(i).raiseSalary(0.18);
        }

        sumOfprice(salesEmployeeArrayList).raiseSalary(1000);




        for (int i =0;i<departmentArrayList.size();i++) {

            output.println(departmentArrayList.get(i).toString());

            for ( int m = 0; m < managerArrayList.size(); m++ ) {

                for ( int dep = 0; dep < departmentArrayList.size(); dep++ ) {

                    if (managerArrayList.get(m).getDepartment().getDepartmentName().equals(departmentArrayList.get(dep).getDepartmentName())) {

                        output.println(managerArrayList.get(m).toString());

                        for ( int dev = 0; dev < developerArrayList.size(); dev++ ) {

                            if (developerArrayList.get(dev).getDepartment().equals(departmentArrayList.get(dep))) {
                                //  prints developer
                                output.print(developerArrayList.get(dev).toString());

                                for ( int p = 0; p < personArrayList.size(); p++ ) {
                                    if (personArrayList.get(p).getId()== developerArrayList.get(dev).getId()) {
                                        output.println(personArrayList.get(p).toString());

                                        for ( int e = 0; e < employeeArrayList.size(); e++ ) {
                                            if (employeeArrayList.get(e).getId() == developerArrayList.get(dev).getId()) {
                                                // employee
                                                output.println(employeeArrayList.get(e).toString());
                                                // regular employee
                                                output.println(developerArrayList.get(dev).getPerson());
                                                output.println(developerArrayList.get(dev).getProjects());
                                                break;
                                            }

                                        }




                                    }

                                }


                            }


                        }

                    }
                }
            }
        }

        output.println("**************CUSTOMER*******************");
        for (int i =0;i<customerArrayList.size();i++){

            output.println(customerArrayList.get(i).toString());
        }
        output.println("**************PEOPLE*******************");
        for (int i =0;i<personArrayList.size();i++) {
            output.println(personArrayList.get(i).toString());

        }
    output.close();
    }



    public static SalesEmployee sumOfprice (ArrayList<SalesEmployee> salesEmployeeArrayList) {
        int max=0;
        int index=0;
        for ( int i = 0; i < salesEmployeeArrayList.size(); i++ ) {

            int sum=1;


            for ( int j = 0; j < salesEmployeeArrayList.get(i).getSales().size(); j++ ) {

                sum*=salesEmployeeArrayList.get(i)   .getSales().get(j).getPrice();


            }
            if (sum<max) {
                index = i;
            }   }

        return salesEmployeeArrayList.get(index);

    }

}
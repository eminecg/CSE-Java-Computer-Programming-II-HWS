import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Employee extends Person {

    private double salary;

    private java.util.Calendar hireDate;
    private Department department;

    public static int numberOfEmployees;


    public Employee(int id, String firstname, String lastname, String gender, Calendar birtDate, String maritalStatus, String hasDriverLisence, double salary, Calendar hireDate, Department department) {
        super(id, firstname, lastname, gender, birtDate, maritalStatus, hasDriverLisence);
        this.salary = salary;
        this.hireDate = hireDate;
        this.department = department;


    }

    public Employee(Person person, double salary, Calendar hireDate, Department department) {
        super(person.getId(), person.getFirstname(), person.getLastname(), person.getGender(), person.getBirtDate(), person.getMaritalStatus(), person.getHasDriverLisence());
        this.salary = salary;
        this.hireDate = hireDate;

        this.department = department;

        numberOfEmployees++;
    }
    public double raiseSalary(double percent ){
        // dogru mu ?
       return  salary*=(percent+1);

    }
    public double raiseSalary(int amount ){

         return salary+=amount;

    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

public String  getHireDate2() {



        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

        return format.format(hireDate.getTime());
    }





    public Calendar getHireDate() {
return hireDate;

    }

    public void setHireDate(Calendar hireDate) {
        this.hireDate = hireDate;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }



    @Override
    public String toString() {
        return "                       Employee Info[" +
                        "salary=" + salary +
                        " hire date=" + getHireDate2() +

                ']';

    }
    public  String getPerson(){
        return super.toString();
    }


}
import java.util.ArrayList;
import java.util.Calendar;

public class Developer extends RegularEmployee {

    private ArrayList<Project> projects=new ArrayList<Project>();

    public  static int  numberOfDevelopers;


    public Developer(int id, String firstname, String lastname, String gender, Calendar birtDate, String maritalStatus, String hasDriverLisence, double salary, Calendar hireDate, Department department, double performanceScore, ArrayList<Project> p) {
        super(id, firstname, lastname, gender, birtDate, maritalStatus, hasDriverLisence, salary, hireDate, department, performanceScore);
        this.projects = p;
        numberOfDevelopers++;
       // System.out.println(this);
    }

    public Developer(RegularEmployee re , ArrayList<Project> p){

        super(re.getId(),re.getFirstname(),re.getLastname(),re.getGender(),re.getBirtDate(),re.getMaritalStatus(),re.getHasDriverLisence(),re.getSalary(),re.getHireDate(),re.getDepartment(),re.getPerformanceScore());
        this.projects=p;
        numberOfDevelopers++;
       // System.out.println(this);

    }

    public ArrayList<Project> getProjects() {
        return projects;
    }

    public void setProjects(ArrayList<Project> projects) {
        this.projects = projects;
    }

    public boolean addProject(Project s) {
        return projects.add(s);

    }
public boolean removeProject(Product s) {
        return projects.remove(s);

}

    public ArrayList<Project> getRemoveProject() {
        return projects;
    }

    public void setRemoveProject(ArrayList<Project> project) {
        this.projects = projects;
    }

public  String getPerson(){
        return super.toString();
}
    @Override
    public String toString() {
        return "                1. Developer \n" +
                "                       Person Info [ " ;

    }
}


import java.util.ArrayList;
import java.util.Calendar;

public class Customer extends Person  {

    private ArrayList<Product> products=new ArrayList<Product>();

    public Customer(int id, String firstname, String lastname, String gender, Calendar birtDate, String maritalStatus, String hasDriverLisence, ArrayList<Product> products) {
        super(id, firstname, lastname, gender, birtDate, maritalStatus, hasDriverLisence);
        this.products = products;

    }

    public Customer(Person person , ArrayList<Product> products) {
        super(person.getId(), person.getFirstname(), person.getLastname(), person.getGender(), person.getBirtDate(), person.getMaritalStatus(), person.getHasDriverLisence());
        this.products = products;


    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }


    @Override
    public String toString() {
        return "Customer{" +
                "id : "+getId()+
                "products=" + products +
                '}';
    }
}

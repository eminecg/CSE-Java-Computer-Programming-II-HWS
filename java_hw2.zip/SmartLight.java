
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class SmartLight extends SmartObject implements LocationControl , Programmable{

    // Takes the value of true if the light is turned on
    private boolean hasLightTurned;
    //Keeps the exact time of automatic activation
    private Calendar programTime;
    // Keeps the next action
    private boolean programAction;


    public SmartLight(String alias, String macId){
        setAlias(alias);
        setMacId(macId);

    }
    //After controlling the connection and status of light ,turn on light and sets the  parameters
    public void turnOnLight(){
        if(controlConnection()){
            if(!hasLightTurned){

                setHasLightTurned(true);
                setProgramAction(false);

                // Instance time
                Calendar current = Calendar.getInstance();
                String time = current.get(Calendar.HOUR_OF_DAY)+":"+current.get(Calendar.MINUTE)+":"+current.get(Calendar.SECOND);

                System.out.println("Smart Light - "+getAlias()+ " is turned on now  (Current time: "+time+")");
        }
            else {
                System.out.println("Smart Light - "+getAlias()+ " has been already turned on ");
            }
    }
    }
    //After controlling the connection ,turn off light and sets the  parameters
    public void turnOffLight(){
            if(controlConnection()){
                if(hasLightTurned){

                    setHasLightTurned(false);
                    setProgramAction(true);

                    // Instance time
                    Calendar current = Calendar.getInstance();
                    String time = current.get(Calendar.HOUR_OF_DAY)+":"+current.get(Calendar.MINUTE)+":"+current.get(Calendar.SECOND);

                    System.out.println("Smart Light - "+getAlias()+ " is turned off now  (Current time: "+time+")");
                }
                else {
                    System.out.println("Smart Light - "+getAlias()+ " has been already turned off ");
                }
            }
        }

        // After controlling the connecion , tests the functionalities of the smart light
    @Override
    public boolean testObject() {
        if(controlConnection()){
            System.out.println("Test is starting for SmartLight ");

            SmartObjectToString();
            turnOnLight();
            turnOffLight();

            System.out.println("Test completed for SmartLight \n");
            return true;
        } //If the smart camera object was not connected to the system,returns false
        else
            return false;
    }
    // After controlling the connecion, method turn off the light (if it has been already turned on)
    @Override
    public boolean shutDownObject() {
        if (controlConnection()) {

            SmartObjectToString();

            if (hasLightTurned) {
                turnOffLight();
            }
            return true;
        }// if not connection , return false
        else
                return false;
    }
    //After controlling the connecion,method turn off the light.
    @Override
    public void onleave() {
        if (controlConnection()) {

           System.out.println("On Leave -> Smart Light - "+getAlias()  );
            turnOffLight();
        }
    }
    //After controlling the connecion,method turn on the light.
    @Override
    public void onCome() {
        if (controlConnection()) {

            System.out.println("On Come -> Smart Light - "+getAlias() );
            turnOnLight();
        }
    }
    //Sets the programTime with the given amount of seconds and prints message depend on the hasLightTurned property
    @Override
    public void setTimer(int seconds) {
        if (controlConnection()) {

            Calendar current = Calendar.getInstance();
            Calendar temp=current;
            setProgramTime(current);

            String time = temp.get(Calendar.HOUR_OF_DAY)+":"+current.get(Calendar.MINUTE)+":"+current.get(Calendar.SECOND);

            //Adding amoount of second to the current time
            current.add(Calendar.SECOND,seconds);

            setProgramTime(current);
            if(hasLightTurned){
                System.out.print("Smart light - "+getAlias()+" will be turned off "+ seconds+" seconds later! ");
                System.out.println("(Current time: "+time+")");
        }
            else {
                System.out.print("Smart light - "+getAlias()+" will be turned on "+ seconds+ " seconds later! ");
                System.out.println("(Current time: "+time+")");
            }
        }
    }
    //After controlling the connection ,cancels the timer of a smart light
    @Override
    public void cancelTimer() {
        if(controlConnection()){

            setProgramTime(null);
        }
    }
    //After controlling the connection ,either turn on or turn off the light depending the programAction property
    @Override
    public void runProgram() {
        DateFormat sdf=new SimpleDateFormat("HH:mm:ss");

        if(controlConnection()) {

            //Getting formatted time
            Calendar current = Calendar.getInstance();

            //Handling NullPointerException
                if(getProgramTime()!=null){
                    String currentTime=sdf.format(current.getTime());
                    String formattedProgramTime=sdf.format(this.getProgramTime().getTime());

             //Checking whether program Time matches the current Time
            if (formattedProgramTime.equals(currentTime)){
                System.out.println("RunProgram -> Smart Light - "+getAlias());

                if (isProgramAction()) {
                    this.turnOnLight();
                    this.cancelTimer();
                }
                else{
                    this.turnOffLight();
                    this.cancelTimer();
                } } }}}

    // Getter And Setter Methods
    public boolean isHasLightTurned() {
        return hasLightTurned;
    }

    public void setHasLightTurned(boolean hasLightTurned) {
        this.hasLightTurned = hasLightTurned;
    }

    public Calendar getProgramTime() {
        return programTime;
    }

    public void setProgramTime(Calendar programTime) {
        this.programTime = programTime;
    }

    public boolean isProgramAction() {
        return programAction;
    }

    public void setProgramAction(boolean programAction) {
        this.programAction = programAction;
    }
}

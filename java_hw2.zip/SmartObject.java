
public abstract class SmartObject {

    // Represents the name of a smart device
    private  String alias;
    // Each device has a unique ıd to connect to the internet
    private String macId;
    // Internet protocol to communicate other devices
    private String IP;
    // Whether the smart object is connected to the internet or not
    private boolean connectionStatus;


    public SmartObject()   {

    }
    //Connect the device
    public boolean connect(String IP){

        setIP(IP);
        setConnectionStatus(true);

        System.out.println(this.alias+" connection established");

        return true;

    }
    //DisConnect the device
    public boolean disconnect(){

        //Sets the IP
        setIP(null);
        setConnectionStatus(false);

           return true;
    }
    //Prints the details about a smart object
    public void SmartObjectToString(){

            System.out.println("This is "+this.getClass().getName()+" device "+getAlias());
            System.out.println("\tMacId: " + macId  +"\n\tIP: "+ IP );

    }
    //Controls the connection of the smart object
    public boolean controlConnection(){

        if(!connectionStatus) {

            System.out.println("This "+this.getClass().getName()+" is not connected." + getClass().getName()+" -> " + this.alias);

            return false;
        }
        else {
            return true;
        }

    }
    // Abstract methods
    public abstract boolean testObject();
    public abstract boolean shutDownObject();


    // Getter and setter methods

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getMacId() {
        return macId;
    }

    public void setMacId(String macId) {
        this.macId = macId;
    }

    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }

    public boolean isConnectionStatus() {
        return connectionStatus;
    }

    public void setConnectionStatus(boolean connectionStatus) {
        this.connectionStatus = connectionStatus;
    }
}

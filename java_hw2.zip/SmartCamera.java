public class SmartCamera extends SmartObject implements MotionControl ,Comparable<SmartCamera> {
        //Takes the value of true if the camera is recording
        private boolean status ;
        //The battery life of the camera
        private  int batteryLife;
        //The night vision feature of the camera
        private boolean nightVision;


    public SmartCamera(String alias,String macId,boolean nightVision,int batteryLife) {
            setAlias(alias);
            setMacId(macId);

            this.batteryLife = batteryLife;
            this.nightVision = nightVision;
    }
    //After checking the connection of a smart camera ,depending on the isDay and the nightVision values it starts recording
    public  void recordOn(boolean isDay){
        if(controlConnection()){
            if(isDay){
                if (!status){

                    System.out.println("Smart Camera - " + getAlias() + " is turned on now");
                    setStatus(true);
                }
                else{
                    System.out.println("Smart Camera - "+getAlias() +"  has been already turned on ");
                }
            }
            //The time of the day is night time
            else {

                if (!nightVision) {
                    System.out.println("Sorry! Smart Camera - " + getAlias() + " does not have night vision feature.");
                }
                else {
                    if (!status){
                        System.out.println("Smart Camera - " + getAlias() + " is turned on now");
                        setStatus(true);
                }
                    else{
                        System.out.println("Smart Camera - "+getAlias() +"  has been already turned on ");
                    } } } } }
    //After checking the connection of a smart camera ,depending on the status value it stops recording
    public void recordOff(){
        if(controlConnection()){

                if (status){
                    System.out.println("Smart Camera - "+getAlias()+" Cam is turned off now ");
                    setStatus(false);
                }
                else{
                    System.out.println("Smart Camera - "+getAlias() +"  has been already turned off ");
                }
            }

    }// After controlling the connection , tests the functionalities of the smart camera
    @Override
    public boolean testObject() {

        if(controlConnection()){
            System.out.println("Test is starting for SmartCamera ");
            SmartObjectToString();

            System.out.println("Test is starting for SmartCamera day time");
            recordOn(true);
            recordOff();

            System.out.println("Test is starting for SmartCamera night time ");
            recordOn(false);
            recordOff();

            System.out.println("Test completed for SmartCamera\n");
        return true;
    }
        //If the smart camera object was not connected to the system,returns false
        else
            return false;
    }

    // After controlling the connecion, method turn off the plug (if it has been already turned on)
    @Override
    public boolean shutDownObject() {
        if (controlConnection()) {

            SmartObjectToString();

            if (status) {
                recordOff();
            }
            return true;
        }//If the smart camera object was not connected to the system,returns false
        else
            return false;
    }
    //After checking the hasMotion ,isDay and nightVision properties ;it starts recording or not with appropriate messages
    @Override
    public boolean controlMotion(boolean hasMotion, boolean isDay) {

                if(hasMotion){
                    System.out.println("Motion detected! ");
                    if(isDay){
                        setStatus(true);
                        System.out.println("Smart Camera - "+getAlias()+" is turned on now ");
                        return  true ;
                    }
                    else{
                        if(nightVision){
                            setStatus(true);
                            System.out.println("Smart Camera - "+getAlias()+" is turned on now ");
                            return true;
                        }
                        else
                            setStatus(false);
                            return false;

                    }
                }//If the smart camera object was not found a motion to the system,returns false
                else
                    System.out.println("Motion is not detected!");
                return false;

    }
    //After checking the batteryLife of the smart camera with the given parameter, returns -1,0,1

    @Override
    public int compareTo(SmartCamera o) {
        if (o.batteryLife > getBatteryLife()) {
            return -1;

        } else if (o.batteryLife == batteryLife) {
            return 0;

        } else
            return 1;

    }
    //Method returns a representative string for the smart camera
    @Override
    public String toString() {
        return "SmartCamera -> "+getAlias()+"'s battery life is "+batteryLife+" status is recording ";
    }
    // Getter and Setter Methods

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getBatteryLife() {
        return batteryLife;
    }

    public void setBatteryLife(int batteryLife) {
        this.batteryLife = batteryLife;
    }

    public boolean isNightVision() {
        return nightVision;
    }

    public void setNightVision(boolean nightVision) {
        this.nightVision = nightVision;
    }

}

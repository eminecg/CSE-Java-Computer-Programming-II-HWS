
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class SmartPlug  extends SmartObject implements Programmable{
   // Takes the value of true if the plug is turned on
   private boolean status;
   //Keeps the exact time of automatic activation
   private Calendar programTime;
   //Keeps the next action of the smart device
   private boolean programAction;

   public SmartPlug( String alias,String macId){
        setAlias(alias);
        setMacId(macId);
   }
   //After controlling the connection , turn on the smartPlug by printing the power on time
    public void turnOn (){
        if(controlConnection()){
            if(!isStatus()){
                //Sets the properties
                setStatus(true);
                setProgramAction(false);

                Calendar current = Calendar.getInstance();
                String time = current.get(Calendar.HOUR_OF_DAY)+":"+current.get(Calendar.MINUTE)+":"+current.get(Calendar.SECOND);

                System.out.println("Smart Plug - "+getAlias()+ " is turned on now  (Current time: "+time+")");
            }
            else {
                System.out.println("Smart PLug - "+getAlias()+ " has been already turned on ");
            }
        }
    }//After controlling the connection , turn off the smartPlug by printing the power on time
    public void turnOff(){
        if(controlConnection()){
            if(isStatus()){
                //Sets the properties
                setStatus(false);
                setProgramAction(true);

                Calendar current = Calendar.getInstance();
                String time = current.get(Calendar.HOUR_OF_DAY)+":"+current.get(Calendar.MINUTE)+":"+current.get(Calendar.SECOND);

                System.out.println("Smart Plug - "+getAlias()+ " is turned off now  (Current time: "+time+")");
            }
            else {
                System.out.println("Smart Plug - "+getAlias()+ " has been already turned off ");
            }
        }
    }
    // After controlling the connection , tests the functionalities of the smart plug
    @Override
    public boolean testObject() {
           if(controlConnection()){

               System.out.println("Test is starting for SmartPlug ");
               SmartObjectToString();
               turnOn();
               turnOff();
               System.out.println("Test completed for SmartPlug\n ");
               return true;
           } //If the smart camera object was not connected to the system,returns false
           else
               return false;
    }
    //After controlling the connection, method turn off the plug (if it has been already turned on)
    @Override
    public boolean shutDownObject() {
        if (controlConnection()) {

            SmartObjectToString();
            if (isStatus()) {
                turnOff();
        }
            return true;
        }
        else
            return false;
    }
    //Sets the programTime with the given amount of seconds and prints message depend on the status property
    @Override
    public void setTimer(int seconds) {
        if (controlConnection()) {

            Calendar current = Calendar.getInstance();
            setProgramTime(current);

            Calendar temp=current;
            String time = temp.get(Calendar.HOUR_OF_DAY)+":"+current.get(Calendar.MINUTE)+":"+current.get(Calendar.SECOND);

            //Adding amoount of second to the current time
            current.add(Calendar.SECOND,seconds);

            setProgramTime(current);

            if(isStatus()){
                System.out.print("Smart plug - "+getAlias()+" will be turned off "+ seconds+" seconds later! ");
                System.out.println("(Current time: "+time+")");
                setProgramAction(false);
            }
            else {
                System.out.print("Smart plug - "+getAlias()+" will be turned on "+ seconds+ " seconds later! ");
                System.out.println("(Current time: "+time+")");
                setProgramAction(true);
            } } }
     //After controlling the connection ,cancels the timer of a smart plug
    @Override
    public void cancelTimer() {
       if(controlConnection()) {
           setProgramTime(null);
       }
    }
    //After controlling the connection ,either turn on or turn off the smart plug depending the programAction property
    @Override
    public void runProgram() {
        DateFormat sdf=new SimpleDateFormat("HH:mm:ss");

        if (controlConnection()) {
            //Getting formatted time
            Calendar current = Calendar.getInstance();

                //Handling NullPointerException
                if(getProgramTime()!=null){

                    //Checking whether program Time matches the current Time
                    String currentTime=sdf.format(current.getTime());
                    String formattedProgramTime=sdf.format(this.getProgramTime().getTime());

                    if (formattedProgramTime.equals(currentTime)){
                    System.out.println("RunProgram -> Smart Plug - " + getAlias());
                    if (isProgramAction()) {
                        turnOn();
                        this.cancelTimer();
                    } else {
                        turnOff();
                        this.cancelTimer();
                    }
                }
            }
        }
    }
    // Getter and Setter Methods
    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Calendar getProgramTime() {
        return programTime;
    }

    public void setProgramTime(Calendar programTime) {
        this.programTime = programTime;
    }

    public boolean isProgramAction() {
        return programAction;
    }

    public void setProgramAction(boolean programAction) {
        this.programAction = programAction;
    }

}

public interface MotionControl {
    //Control paramethers ,the first one presence of motion and the second one represents whether it is daytime or night time
    boolean controlMotion( boolean hasMotion ,boolean isDay);

}

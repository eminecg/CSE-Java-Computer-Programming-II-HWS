    //Controlling a smart device based on the location of a household.
    public interface LocationControl  {
    //  Turning on a device automatically before coming
      void onleave();
    // Turning off a device automatically after leaving
      void onCome();



    }

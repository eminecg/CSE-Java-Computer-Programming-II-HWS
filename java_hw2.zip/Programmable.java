// The property of programming a smart device
public interface Programmable {
    //The device should be turned on or turned off after given amount of seconds value
      void setTimer(int seconds);
     // To cancel the timer of a smart device
      void cancelTimer();
     // Method checks the program time of a smart device when its timer is set ,controls whether match with the current time
     void runProgram();

}

import java.util.ArrayList;
import java.util.Collections;

public class SmartHome  {
    private ArrayList<SmartObject> smartObjectsList=new ArrayList<SmartObject>();

    public SmartHome(){

    }// Method adds given smart Object to the smart object list ,then sets IP value with index value and prints appropriate message
    public boolean addSmartObject(SmartObject smartObject){

        String temp="10.0.0.";
        getSmartObjectsList().add(smartObject);
        int index =smartObjectsList.indexOf(smartObject)+100;
        String newIP=temp.concat(String.valueOf(index));

        System.out.println("--------------------------------------------------------------------------");
        System.out.println("--------------------------------------------------------------------------");
        System.out.println("Adding new SmartObject");
        System.out.println("--------------------------------------------------------------------------");

        smartObject.connect(newIP);

        smartObject.testObject();

        return true;
    }
    //Method removes the given smartObject from the smartObjectList.
    public boolean removeSmartObject(SmartObject smartObject){
       return smartObjectsList.remove(smartObject);
    }
    //Method traverses the smartObjectList for find an object implementing LocationControl interface, invokes onCome or onLeave method depending onCome boolean parameter
    public void controlLocation(boolean onCome){
        int i=0;
        for(SmartObject object: smartObjectsList ){
            if(object instanceof LocationControl ){
                if(onCome){

                    for(;i<1;i++) {
                        System.out.println("--------------------------------------------------------------------------");
                        System.out.println("--------------------------------------------------------------------------");
                        System.out.println("LocationControl : OnCome ");
                        System.out.println("--------------------------------------------------------------------------");
                    }

                    ((LocationControl) object).onCome();
                    continue;
                }
                // onCome value is false
                else  {
                    for(;i<1;i++) {
                        System.out.println("--------------------------------------------------------------------------");
                        System.out.println("--------------------------------------------------------------------------");
                        System.out.println("LocationControl : OnLeave ");
                        System.out.println("--------------------------------------------------------------------------");
                    }
                    ((LocationControl) object).onleave();
                    continue;
            } } }}
     //Method traverses the smartObjectList for find an object implementing MotionControl interface invokes controlMotion depending on hasMotion and isDay boolean parameters
    public void controlMotion(boolean hasMotion,boolean isDay ) {
        int i=0;
        for ( SmartObject object : smartObjectsList ) {
            if (object instanceof MotionControl) {
                for(;i<1;i++) {
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("MotionControl: HasMotion, isDay ");
                    System.out.println("--------------------------------------------------------------------------");
                }
                ((MotionControl) object).controlMotion(hasMotion, isDay);
            } } }
     //Method traverses the smartObjectList for find an object implementing Programmable interface, invokes its method runProgram
    public void controlProgrammable (){
        int i=0;
        for ( SmartObject object : smartObjectsList ) {
            if (object instanceof Programmable) {
                for(;i<1;i++) {
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("Programmable: runProgram  ");
                    System.out.println("--------------------------------------------------------------------------");
                }
                ((Programmable) object).runProgram();
            } } }
            //Method traverses the smartObjectList for find a smart object implementing Programmable interface and then it invokes setTimer method with given seconds value
    public void controlTimer(int seconds){
        int i=0;
        for ( SmartObject object : smartObjectsList ) {
            if (object instanceof Programmable) {
                for(;i<1;i++) {
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("Programmable: Timer = "+seconds+" seconds  ");
                    System.out.println("--------------------------------------------------------------------------");
                }
                if(seconds>0){

                ((Programmable) object).setTimer(seconds);
            }// İf seconds is zero, it invokes cancel timer method
                else if(seconds==0){
                    ((Programmable) object).cancelTimer();

                } } } }
    //Method traverses the smartObjectList for find a smart object implementing Programmable interface and
    // then it invokes setTimer method with getting random second value(0,5,10)
    public void controlTimerRandomly(){
        int i=0;
        for ( SmartObject object : smartObjectsList ) {

            if (object instanceof Programmable) {

             int [] seconds ={0,5,10};
             int second =seconds[(int)(Math.random()*3)];

                for(;i<1;i++) {
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println("Programmable: Timer = 0, 5 or 10 seconds randomly  ");
                    System.out.println("--------------------------------------------------------------------------");
                }

             if(second==0){
                 ((Programmable) object).cancelTimer();
             }
             else {
                 ((Programmable) object).setTimer(second);
             } } } }
     // Method traverses the smartObjectList for find a smart object implementing Comparable interface,then invokes sort method base on the battery life
    public void sortCameras(){
        //Creating an ArrayList for smart camera objects
        ArrayList<SmartCamera> smartCameraList=new ArrayList<SmartCamera>();
        for ( SmartObject object : smartObjectsList ) {
            if (object instanceof SmartCamera) {

                //Adding smart camera object to the list
              smartCameraList.add((SmartCamera) object);

              //Sorting smart camera list based on the battery life
                Collections.sort(smartCameraList);

            }}
            System.out.println("--------------------------------------------------------------------------");
            System.out.println("--------------------------------------------------------------------------");
            System.out.println("Sort Smart Cameras  ");
            System.out.println("--------------------------------------------------------------------------");

            for( SmartCamera camera: smartCameraList){
                System.out.println(camera.toString());
            }
        }

    // Getter and Setter Methods
    public ArrayList<SmartObject> getSmartObjectsList() {
        return smartObjectsList;
    }

    public void setSmartObjectsList(ArrayList<SmartObject> smartObjectsList) {
        this.smartObjectsList = smartObjectsList;
    }
}
